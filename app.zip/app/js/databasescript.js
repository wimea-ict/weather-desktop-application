  var mydb ="";
  var usernamestored =""
var app = angular.module('myApp', []);
if (window.openDatabase) {
    //Create the database the parameters are 1. the database name 2.version number 3. a description 4. the size of the database (in bytes) 1024 x 1024 = 1MB
    mydb = openDatabase("observerData_db", "0.1", "A Database of Cars I Like", 1024 * 1024);

    //create the cars table using SQL for the database using a transaction
    mydb.transaction(function (t) {
        //t.executeSql("CREATE TABLE IF NOT EXISTS cars (id INTEGER PRIMARY KEY ASC, make TEXT, model TEXT)");
        t.executeSql("CREATE TABLE IF NOT EXISTS user_Details_table(userId,username, password, stationName,stationNumber)");
    });

    //alert("database created");

} else {
    alert("WebSQL is not supported by your browser!");
}
app.service('LoginService', function ($q, $http) {
      var user=""; var userId=""; var userStationNo=""; var userStation="";
  return {
    loginUser: function (loginData) {
        var deferred = $q.defer(),
        promise = deferred.promise;


        $http({
          url: 'http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/loginMobile.php',
          method: "POST",
          data: loginData,
          headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        }) .then(function (response) {
          if (response.data.error.code === "000") {
            //console.log("User login successful: " + JSON.stringify(response.data));
            deferred.resolve("Welcome");
            user = response.data.userData.name;
            userStationNo=response.data.userData.stationNumber;
            userStation=response.data.userData.stationName;
            userId=response.data.userData.id;

          } else {
            //console.log("User login failed: " + JSON.stringify(response.data.error));
            deferred.reject("Wrong credential");
          }
        }, function (error) {
          //console.log("Server Error on login: " + JSON.stringify(error));
          deferred.reject("Wrong credential");
        });

        promise.success = function (fn) {
          promise.then(fn);
          return promise;
        };
        promise.error = function (fn) {
          promise.then(null, fn);
          return promise;
        };
        return promise;
      }, getUser: function(){
            return user;
      }, getUserStation: function(){
            return userStation;
      }
      , getUserStationNo: function(){
            return userStationNo;
      },getUserId: function(){
            return userId;
      }
}
})
app.controller("HomeTabCtrl",function($scope,$compile,$http){
  $scope.moreformpart2 = false;
  $scope.moreformpart1 = true;

  $scope.outputUsers = function() {

        //  $scope.createDatabase();
        //check to ensure the mydb object has been created
        if (mydb) {
        //  var username = document.getElementById("username").value;
          //var password = document.getElementById("password").value;

            //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
            mydb.transaction(function (t) {
                t.executeSql("SELECT * FROM user_Details_table", [],
                function(transaction, results){
                  var len = results.rows.length, i;
                  if (len>0) {
                   $scope.usernamefromdb = results.rows.item(0).username;
                   document.getElementById("username_side").innerHTML =results.rows.item(0).username;
                   document.getElementById("useridside").innerHTML =results.rows.item(0).userId;
                   document.getElementById("station_observationslipform").value = results.rows.item(0).stationName;
                   document.getElementById("stationNo_observationslipform").value =results.rows.item(0).stationNumber;
                   document.getElementById("station_moreform").value = results.rows.item(0).stationName;
                   document.getElementById("stationNo_moreform").value =results.rows.item(0).stationNumber;

                  }
                  else{

                  }

                });
            });


        } else {

          }
    }



  window.localStorage['items'] = JSON.stringify([{
      name: 'makerere',
      stationname: 'Cameron Bourke',
      stationnumber: '2',
      userid: '1'
    }]);

        $scope.userstationdetails = JSON.parse(localStorage.getItem('items')) || [];

    $scope.createContact = function() {
          $scope.userstationdetails.push({ name: 'You Owe Me Now',
          stationname: 'Cameron Bourke',
          stationnumber: '2',
          userid: 'You owe me $2 for.'
      });

        };


    //$scope.createContact();

          //alert($scope.userstationdetails.length)
        $scope.onItemDelete = function(item) {
      $scope.contacts.splice($scope.contacts.indexOf(item), 1);
    };

if (window.openDatabase) {
    //Create the database the parameters are 1. the database name 2.version number 3. a description 4. the size of the database (in bytes) 1024 x 1024 = 1MB
  //create the cars table using SQL for the database using a transaction
    mydb.transaction(function (t) {
    t.executeSql(" CREATE TABLE IF NOT EXISTS obseravation_details__table(id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,Date,  StationName,  StationNumber,  TIME,  TotalAmountOfAllClouds, TotalAmountOfLowClouds, TypeOfLowClouds, TypeOfLowClouds2, TypeOfLowClouds3, OktasOfLowClouds, OktasOfLowClouds2, OktasOfLowClouds3, HeightOfLowClouds, HeightOfLowClouds2, HeightOfLowClouds3, CLCODEOfLowClouds, CLCODEOfLowClouds2, CLCODEOfLowClouds3, TypeOfMediumClouds,TypeOfMediumClouds2,"+
    "TypeOfMediumClouds3, OktasOfMediumClouds,OktasOfMediumClouds2,OktasOfMediumClouds3, HeightOfMediumClouds, HeightOfMediumClouds2,HeightOfMediumClouds3,CLCODEOfMediumClouds,CLCODEOfMediumClouds2,CLCODEOfMediumClouds3,TypeOfHighClouds,TypeOfHighClouds2,TypeOfHighClouds3, OktasOfHighClouds, OktasOfHighClouds2,OktasOfHighClouds3,HeightOfHighClouds,HeightOfHighClouds2,HeightOfHighClouds3, CLCODEOfHighClouds, CLCODEOfHighClouds2, CLCODEOfHighClouds3, CloudSearchLightReading, Rainfall,Dry_Bulb,"+ "Wet_Bulb, Max_Read, Max_Reset,Min_Read,  Min_Reset,Piche_Read,Piche_Reset,TimeMarksThermo,TimeMarksHygro,TimeMarksRainRec , Present_Weather,Visibility,Wind_Direction,Wind_Speed ,Gusting,AttdThermo,PrAsRead,Correction,CLP,MSLPr,TimeMarksBarograph,TimeMarksAnemograph,OtherTMarks,Remarks,windrun, sunduration, specitime, SubmittedBy,CreationDate)",
    [],
             function(tx, rs) { //alert("created observationData")
            },
             function(tx, err) { //alert("Error in create table occurred: " +JSON.stringify(err))
           }
           );

    t.executeSql("CREATE TABLE IF NOT EXISTS moreformTable (id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, date,  StationName,  StationNumber,  time,  UnitofWindSpeed, Indoromissionofprecipitation, Typeofstationpresentpastweather,HeightOfLowestCloud , DurationOfPeriodOfPrecipitation, Standardisobaricsurface,  PastWeather,  GrassMininumtemperature,CharacterandIntensityofPrecipitation, BeginningorEndofPrecipitation, Indicatoroftypeofintrumentation, DurationofSunshine,  SignofPressureChange,SupplementaryInformation,VapourPressure,  thgraph, SubmittedBy,CreationDate)",
    [],
             function(tx, rs) { //alert("created more")
           },
             function(tx, err) { //alert("Error in create table occurred: " +JSON.stringify(err))
           });


    });

} else
    alert("WebSQL is not supported by your browser!");
$scope.convertDate=function(date) {
     var yyyy = date.getFullYear().toString();
     var mm = (date.getMonth()+1).toString();
     var dd  = date.getDate().toString();

     var mmChars = mm.split('');
     var ddChars = dd.split('');

     return yyyy + '-' + (mmChars[1]?mm:"0"+mmChars[0]) + '-' + (ddChars[1]?dd:"0"+ddChars[0]);
    }
    $scope.convertTime=function(date) {
     var hh = date.getHours().toString();
     var mm  = date.getMinutes().toString();

     return (hh<10? "0"+hh : hh)+ ':' +(mm<10? "0"+mm : mm) ;
    }
$scope.obv={};
//function to output the list of cars in the database
$scope.submitObservation=function(){

//$scope.addObservationOffline();

  $scope.observationData={
    "date":$scope.convertDate($scope.obv.date),
    "StationName": document.getElementById("station_observationslipform").value,
    "StationNumber": document.getElementById("stationNo_observationslipform").value,
     "time":$scope.obv.time_observationslipform,
     "TotalAmountOfAllClouds":$scope.obv.totalamountofallclouds_observationslipform,
     "TotalAmountOfLowClouds":$scope.obv.totalamountoflowclouds_observationslipform,
      "TypeOfLowClouds":$scope.obv.TypeOfLowClouds1_observationslipform,
      "TypeOfLowClouds2":$scope.obv.TypeOfLowClouds2_observationslipform,
      "TypeOfLowClouds3":$scope.obv.TypeOfLowClouds3_observationslipform,
     "OktasOfLowClouds":$scope.obv.OktasOfLowClouds1_observationslipform,
     "OktasOfLowClouds2":$scope.obv.OktasOfLowClouds2_observationslipform,
     "OktasOfLowClouds3":$scope.obv.OktasOfLowClouds3_observationslipform,
      "HeightOfLowClouds":$scope.obv.HeightLowClouds1_observationslipform,
      "HeightOfLowClouds2":$scope.obv.HeightLowClouds2_observationslipform,
      "HeightOfLowClouds3":$scope.obv.HeightLowClouds3_observationslipform,
     "CLCODEOfLowClouds":$scope.obv.CLCODEOfLowClouds1_observationslipform,
     "CLCODEOfLowClouds2":$scope.obv.CLCODEOfLowClouds2_observationslipform,
     "CLCODEOfLowClouds3":$scope.obv.CLCODEOfLowClouds3_observationslipform,
      "TypeOfMediumClouds":$scope.obv.TypeOfMediumClouds1_observationslipform,
      "TypeOfMediumClouds2":$scope.obv.TypeOfMediumClouds2_observationslipform,
      "TypeOfMediumClouds3":$scope.obv.TypeOfMediumClouds3_observationslipform,
     "OktasOfMediumClouds":$scope.obv.OktasOfMediumClouds1_observationslipform,
     "OktasOfMediumClouds2":$scope.obv.OktasOfMediumClouds2_observationslipform,
     "OktasOfMediumClouds3":$scope.obv.OktasOfMediumClouds3_observationslipform,
     "HeightOfMediumClouds":$scope.obv.HeightOfMediumClouds1_observationslipform,
     "HeightOfMediumClouds2":$scope.obv.HeightOfMediumClouds2_observationslipform,
     "HeightOfMediumClouds3":$scope.obv.HeightOfMediumClouds3_observationslipform,
     "CLCODEOfMediumClouds":$scope.obv.CLCODEOfMediumClouds1_observationslipform,
     "CLCODEOfMediumClouds2":$scope.obv.CLCODEOfMediumClouds2_observationslipform,
     "CLCODEOfMediumClouds3":$scope.obv.CLCODEOfMediumClouds3_observationslipform,
     "TypeOfHighClouds":$scope.obv.TypeOfHighClouds1_observationslipform,
     "TypeOfHighClouds2":$scope.obv.TypeOfHighClouds2_observationslipform,
     "TypeOfHighClouds3":$scope.obv.TypeOfHighClouds3_observationslipform,
       "OktasOfHighClouds":$scope.obv.OktasOfHighClouds1_observationslipform,
       "OktasOfHighClouds2":$scope.obv.OktasOfHighClouds2_observationslipform,
       "OktasOfHighClouds3":$scope.obv.OktasOfHighClouds3_observationslipform,
     "HeightOfHighClouds":$scope.obv.HeightOfHighClouds1_observationslipform,
     "HeightOfHighClouds2":$scope.obv.HeightOfHighClouds2_observationslipform,
     "HeightOfHighClouds3":$scope.obv.HeightOfHighClouds3_observationslipform,
      "CLCODEOfHighClouds":$scope.obv.CLCODEOfHighClouds1_observationslipform,
      "CLCODEOfHighClouds2":$scope.obv.CLCODEOfHighClouds2_observationslipform,
      "CLCODEOfHighClouds3":$scope.obv.CLCODEOfHighClouds3_observationslipform,
      "CloudSearchLightReading":$scope.obv.cloudsearchlight_observationslipform,
      "Rainfall":$scope.obv.rainfall_observationslipform,
      "Dry_Bulb":$scope.obv.drybulb_observationslipform,
       "Wet_Bulb":$scope.obv.wetbulb_observationslipform,
        "Max_Read":$scope.obv.maxRead_observationslipform,
         "Max_Reset":$scope.obv.maxReset_observationslipform,
         "Min_Read":$scope.obv.minRead_observationslipform,
         "Min_Reset":$scope.obv.minReset_observationslipform,
         "Piche_Read":$scope.obv.picheRead_observationslipform,
         "Piche_Reset":$scope.obv.picheReset_observationslipform,
         "TimeMarksThermo":$scope.obv.timemarksThermo_observationslipform,
         "TimeMarksHygro":$scope.obv.timemarksHygro_observationslipform,
         "TimeMarksRainRec":$scope.obv.timemarksRainRec_observationslipform ,
          "Present_Weather":$scope.obv.presentweather_observationslipform,
          "Visibility":$scope.obv.visibility_observationslipform,
         "Wind_Direction":$scope.obv.winddirection_observationslipform,
         "Wind_Speed": $scope.obv.windspeed_observationslipform,
         "Gusting":$scope.obv.gusting_observationslipform,
         "AttdThermo":$scope.obv.attdThermo_observationslipform,
         "PrAsRead":$scope.obv.prAsRead_observationslipform,
         "Correction":$scope.obv.correction_observationslipform,
         "clp":$scope.obv.CLP_observationslipform,
         "MSLPr":$scope.obv.MSLPR_observationslipform,
         "TimeMarksBarograph":$scope.obv.timeMarksBarograph_observationslipform,
         "TimeMarksAnemograph":$scope.obv.timeMarksAnemograph_observationslipform,
         "OtherTMarks":$scope.obv.otherTMarks_observationslipform,
         "Remarks":$scope.obv.remarks_observationslipform,
         "sunduration":$scope.obv.sunshineduration,
         "windrun":$scope.obv.windrun,
         "specitime":$scope.obv.specitime,
         "SubmittedBy":"1221" ,
         "DeviceType":"desktop"
  };



    $http({
   method : "POST",
   url : "http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/observationformScript.php",
   data: $scope.observationData,
  headers: {'Content-Type': 'application/x-www-form-urlencoded'}
  }).then(function mySuccess(response) {
  // $scope.myWelcome = response.data;
  alert("Success"+response.data.message);
  }, function myError(response) {
   //$scope.myWelcome = response.statusText;
  alert("Error"+JSON.stringify(response) );
  });





}
$scope.submitmoreformData=function(){

//$scope.addObservationOffline();

  $scope.moreformData={
    "date":$scope.convertDate($scope.moreform.date),
    "StationName": document.getElementById("station_moreform").value,
    "StationNumber": document.getElementById("stationNo_moreform").value,
    "time":$scope.convertTime($scope.moreform.time_observationslipform),
    "UnitofWindSpeed":$scope.moreform.UnitofWindSpeed,
    "Indoromissionofprecipitation":$scope.moreform.Indoromissionofprecipitation,
    "Typeofstationpresentpastweather":$scope.moreform.Typeofstationpresentpastweather,
    "HeightOfLowestCloud":$scope.moreform.HeightOfLowestCloud,
    "DurationOfPeriodOfPrecipitation":$scope.moreform.DurationOfPeriodOfPrecipitation,
    "Standardisobaricsurface":$scope.moreform.Standardisobaricsurface,
    "PastWeather":$scope.moreform.PastWeather,
    "GrassMininumtemperature":$scope.moreform.GrassMininumtemperature,
    "CharacterandIntensityofPrecipitation":$scope.moreform.CharacterandIntensityofPrecipitation,
    "BeginningorEndofPrecipitation":$scope.moreform.BeginningorEndofPrecipitation,
    "Indicatoroftypeofintrumentation":$scope.moreform.Indicatoroftypeofintrumentation,
    "DurationofSunshine":$scope.moreform.DurationofSunshine,
    "SignofPressureChange":$scope.moreform.SignofPressureChange,
    "SupplementaryInformation":$scope.moreform.SupplementaryInformation,
    "VapourPressure":$scope.moreform.VapourPressure,
    "thgraph":$scope.moreform.thgraph,
    "geopotential":$scope.moreform.gpm,
    "SubmittedBy":document.getElementById("useridside").innerHTML ,
    "DeviceType":"desktop"
  };



    $http({
   method : "POST",
   url : "http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/moreform.php",
   data: $scope.moreformData,
  headers: {'Content-Type': 'application/x-www-form-urlencoded'}
  }).then(function mySuccess(response) {
  // $scope.myWelcome = response.data;
  alert("Success"+response.data.message);
  }, function myError(response) {
   //$scope.myWelcome = response.statusText;
  alert("Error"+JSON.stringify(response) );
  });





}
$scope.loadobvpendingview = function(){

  $scope.observationpart1 = true;
  $scope.observationpart2 = false;
  $scope.observationpart3 = false;
  $scope.observationpart4 = false;

  $scope.moreformpart1 = true;
  $scope.moreformpart2 = false;

  $scope.speedrequired= true;
  $scope.directionrequired= true;
  $scope.visibilityrequired= true;
  $scope.WetBulbrequired= false;
  $scope.DryBulbrequired= false;
  $scope.Timerequired= true;
  $scope.daterequired= true;
  $scope.AllCloudsrequired= true;
  $scope.TotalCloudsrequired= true;
}

$scope.loadmoreviews = function(){
    $scope.outputUsers();

    $scope.moreformpart1 = true;
    $scope.moreformpart2 = false;

}

$scope.loadobvViews = function(){

    $scope.outputUsers();

  $scope.observationpart1 = true;
  $scope.observationpart2 = false;
  $scope.observationpart3 = false;
  $scope.observationpart4 = false;
  $scope.speedrequired= true;
  $scope.directionrequired= true;
  $scope.visibilityrequired= true;
  $scope.WetBulbrequired= true;
  $scope.DryBulbrequired= true;
  $scope.Timerequired= true;
  $scope.daterequired= true;
  $scope.AllCloudsrequired= true;
  $scope.TotalCloudsrequired= true;
}

$scope.openobvView = function(viewname){

  if(viewname == "moreformpart1"){
    $scope.moreformpart2 = false;
    $scope.moreformpart1 = true;
    window.scrollTo(0,0);


  }else  if(viewname == "moreformpart2"){

    //  if($scope.moreform.date!= null){
        $scope.moreformpart2 = true;
        $scope.moreformpart1 = false;
        window.scrollTo(0,0);
/*      }
      else{
          alert("jojosikola")
        if($scope.moreform.time_observationslipform== null) scope.daterequired= false;
        if($scope.moreform.moreform.date== null) scope.Timerequired= false;

      }
*/
    }else if(viewname == "observationpart1"){
    $scope.observationpart1 = true;
    $scope.observationpart2 = false;
    $scope.observationpart3 = false;
    $scope.observationpart4 = false;
  }
  else if(viewname == "observationpart2"){


    if($scope.obv.totalamountofallclouds_observationslipform== null){$scope.AllCloudsrequired=false}
    if($scope.obv.totalamountoflowclouds_observationslipform== null){$scope.TotalCloudsrequired= false}
    if($scope.obv.time_observationslipform==null){$scope.Timerequired= false}
    if($scope.obv.date==null){$scope.daterequired = false}

    if(($scope.obv.time_observationslipform!= null || $scope.obv.specitime!= null) && $scope.obv.date!= null ){
      $scope.observationpart1 = false;
      $scope.observationpart2 = true;
      $scope.observationpart3 = false;
      $scope.observationpart4 = false;

    }

}
else if(viewname == "observationpart3"){


    if($scope.obv.wetbulb_observationslipform==null){$scope.WetBulbrequired = false}
  if($scope.obv.drybulb_observationslipform==null){$scope.DryBulbrequired= false}


   if($scope.obv.time_observationslipform == null){
     $scope.observationpart1 = false;
     $scope.observationpart2 = false;
     $scope.observationpart3 = true;
     $scope.observationpart4 = false;

   }else {
     if($scope.obv.wetbulb_observationslipform!=null && $scope.obv.drybulb_observationslipform!=null){
       //alert($scope.obv.drybulb_observationslipform);
       $scope.observationpart1 = false;
       $scope.observationpart2 = false;
       $scope.observationpart3 = true;
       $scope.observationpart4 = false;
     }
   }


}
else if(viewname == "observationpart4"){
  $scope.observationpart1 = false;
  $scope.observationpart2 = false;
  $scope.observationpart3 = false;
  $scope.observationpart4 = true;


}else{
  if($scope.obv.visibility_observationslipform==null){$scope. visibilityrequired = false}
  if($scope.obv.windspeed_observationslipform==null){$scope.speedrequired= false}
  if($scope.obv.winddirection_observationslipform==null){$scope.directionrequired= false}

    if($scope.obv.visibility_observationslipform!=null && $scope.obv.windspeed_observationslipform!=null && $scope.obv.winddirection_observationslipform!=null){
      //  alert("makes");
    $scope.checkConnection();

    }
}

}

  $scope.checkConnection =function() {
        var xhr = new XMLHttpRequest();
        var file = "https://www.google.com/";
        var randomNum = Math.round(Math.random() * 10000);

        xhr.open('HEAD', file + "?rand=" + randomNum, true);
        xhr.send();

        xhr.addEventListener("readystatechange", processRequest, false);

        function processRequest(e) {
          if (xhr.readyState == 4) {
            if (xhr.status >= 200 && xhr.status < 304) {
              alert("Internet is available! The data is going to be submitted online");
              $scope.submitObservation();
            } else {
              alert("Due to internet unavailability, the data is going to be saved offline");
                $scope.addObservationOffline();
            }
          }
        }
    }

    $scope.checkConnectionmore =function() {
          var xhr = new XMLHttpRequest();
          var file = "https://www.google.com/";
          var randomNum = Math.round(Math.random() * 10000);

          xhr.open('HEAD', file + "?rand=" + randomNum, true);
          xhr.send();

          xhr.addEventListener("readystatechange", processRequest, false);

          function processRequest(e) {
            if (xhr.readyState == 4) {
              if (xhr.status >= 200 && xhr.status < 304) {
                alert("Internet is available! The data is going to be submitted online");
                $scope.submitmoreformData();
              } else {
                alert("Due to internet unavailability, the data is going to be saved offline");
                  $scope.addmoreformOffline();
              }
            }
          }
      }


$scope.observationData = [];
$scope.moredata = [];
var huh = false;
$scope.showNawe = function(){
  $scope.outputUsers();
  $.when($scope.openLine(function (users){
    $scope.observationData = users;
        $scope.openme(users);
      ////alert($scope.observationData+"jozhu<ddd");

    },function(details){
      $scope.moredata = details;
          $scope.openmore2(details);
    })).then(//alert($scope.observationData +"failed<ddd")
  );






}
$scope.openmore2 = function(user){
  $scope.moredata = user;
  ////alert($scope.observationData +"testing if data comes");
  var innerContent =        ' <div class="table" id>' +
' <div class="row header blue">'+
  ' <div class="cell">'+
  '  Record type'+
  ' </div>'+
  ' <div class="cell">'+
    ' Date and Time'+
  ' </div>'+
  ' <div class="cell">'+
  '   Edit'+
  ' </div>'+
  ' <div class="cell">'+
  '   Upload'+
  ' </div>'+
' </div>';

for(i = 0; i<$scope.moredata.length; i++ ){
  //alert($scope.moredata[i].id + "id");
  ////alert($scope.observationData[i].name);
  x = "sssssss";
  innerContent += ' <div class="row" >'+
    ' <div class="cell">'+
      'More data form'+
    ' </div>'+
    '<div class="cell">'+$scope.moredata[i].name+' </div>'+
    ' <div class="cell">'+
      ' <button class="btn btn-primary button-size" ng-click = "openModalMoreData(1)">edit</button>'+
    ' </div>'+
    ' <div class="cell">'+
      ' <button class="btn btn-success button-size" ng-click = "uploadDetails(\''+$scope.moredata[i].id+'\')">Upload</button>'+
     ' </div>'+
   ' </div>';
}

 innerContent +='</div>';

  document.getElementById("pendingUploads2").innerHTML = innerContent;

  $compile(document.getElementById("pendingUploads2"))($scope);



}

$scope.openme = function(user){
  $scope.observationData = user;
  ////alert($scope.observationData +"testing if data comes");
  var innerContent =        ' <div class="table" id>' +
' <div class="row header blue">'+
  ' <div class="cell">'+
  '  Record type'+
  ' </div>'+
  ' <div class="cell">'+
    ' Date and Time'+
  ' </div>'+
  ' <div class="cell">'+
  '   Edit'+
  ' </div>'+
  ' <div class="cell">'+
  '   Upload'+
  ' </div>'+
' </div>';

for(i = 0; i<$scope.observationData.length; i++ ){
  ////alert($scope.observationData[i].name);
  x = "sssssss";
  innerContent += ' <div class="row" >'+
    ' <div class="cell">'+
      'Observation form'+
    ' </div>'+
    '<div class="cell">'+$scope.observationData[i].name+' </div>'+
    ' <div class="cell">'+
      ' <button class="btn btn-primary button-size" ng-click = "openModal(\''+$scope.observationData[i].id+'\')">edit</button>'+
    ' </div>'+
    ' <div class="cell">'+
      ' <button class="btn btn-success button-size" ng-click = "uploadDetails(\''+$scope.observationData[i].id+'\')">Upload</button>'+
     ' </div>'+
   ' </div>';
}

 innerContent +='</div>';

  document.getElementById("pendingUploads").innerHTML = innerContent;

  $compile(document.getElementById("pendingUploads"))($scope);



}

  $scope.selectObservation = function(data_id, callback){
    if (mydb) {
            var detailsselected = [];
        //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
        mydb.transaction(function (t) {
          var demo = [];
            t.executeSql("SELECT * FROM obseravation_details__table where id=?", [data_id],   function(transaction, results) {
                //initialise the listitems variable
                  if(results.rows.length> 0){
                      var row = results.rows.item(0);
                    detailsselected[0] = row;
                      callback(detailsselected);

                  }

            });

        });

    } else {
        //alert("db not found, your browser does not support web sql!");

    }

  }

  $scope.selectmoredata = function(data_id, callback){
    //alert("selecting more data");
    if (mydb) {
            var detailsselected = [];
        //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
        mydb.transaction(function (t) {
          var demo = [];
            t.executeSql("SELECT * FROM moreformTable where id=?", [data_id],   function(transaction, results) {
                //initialise the listitems variable
                  if(results.rows.length> 0){
                   //alert("data is coming" + results.rows.item(0).date)
                      var row = results.rows.item(0);
                    detailsselected[0] = row;
                      callback(detailsselected);

                  }
                    //alert("data is not coming")

            });

        });

    } else {
        //alert("db not found, your browser does not support web sql!");

    }

  }

$scope.uploadDetails= function (data_id){

  $scope.selectObservation(data_id, function (users){
  //  $scope.observationData = users;
      //  $scope.openme(users);
        ////alert(users.length);

        $scope.observationData={
          "date":users[0].Date,
          "StationName":users[0].StationName,
          "StationNumber":users[0].StationNumber,
           "time":users[0].TIME,
           "TotalAmountOfAllClouds":users[0].TotalAmountOfAllClouds,
           "TotalAmountOfLowClouds":users[0].TotalAmountOfLowClouds,
            "TypeOfLowClouds":users[0].TypeOfLowClouds,
            "TypeOfLowClouds2":users[0].TypeOfLowClouds2,
            "TypeOfLowClouds3":users[0].TypeOfLowClouds3,
           "OktasOfLowClouds":users[0].OktasOfLowClouds,
           "OktasOfLowClouds2":users[0].OktasOfLowClouds2,
           "OktasOfLowClouds3":users[0].OktasOfLowClouds3,
            "HeightOfLowClouds":users[0].HeightOfLowClouds,
            "HeightOfLowClouds2":users[0].HeightOfLowClouds2,
            "HeightOfLowClouds3":users[0].HeightOfLowClouds3,
           "CLCODEOfLowClouds":users[0].CLCODEOfLowClouds,
           "CLCODEOfLowClouds2":users[0].CLCODEOfLowClouds2,
           "CLCODEOfLowClouds3":users[0].CLCODEOfLowClouds3,
            "TypeOfMediumClouds":users[0].TypeOfMediumClouds,
            "TypeOfMediumClouds2":users[0].TypeOfMediumClouds2,
            "TypeOfMediumClouds3":users[0].TypeOfMediumClouds3,
           "OktasOfMediumClouds":users[0].OktasOfMediumClouds,
           "OktasOfMediumClouds2":users[0].OktasOfMediumClouds2,
           "OktasOfMediumClouds3":users[0].OktasOfMediumClouds3,
           "HeightOfMediumClouds":users[0].HeightOfMediumClouds,
           "HeightOfMediumClouds2":users[0].HeightOfMediumClouds2,
           "HeightOfMediumClouds3":users[0].HeightOfMediumClouds3,
           "CLCODEOfMediumClouds":users[0].CLCODEOfMediumClouds,
           "CLCODEOfMediumClouds2":users[0].CLCODEOfMediumClouds2,
           "CLCODEOfMediumClouds3":users[0].CLCODEOfMediumClouds3,
           "TypeOfHighClouds":users[0].TypeOfHighClouds,
           "TypeOfHighClouds2":users[0].TypeOfHighClouds2,
           "TypeOfHighClouds3":users[0].TypeOfHighClouds3,
              "OktasOfHighClouds":users[0].OktasOfHighClouds,
             "OktasOfHighClouds2": users[0].OktasOfHighClouds2,
             "OktasOfHighClouds3":users[0].OktasOfHighClouds3,
           "HeightOfHighClouds":users[0].HeightOfHighClouds,
           "HeightOfHighClouds2":users[0].HeightOfHighClouds2,
           "HeightOfHighClouds3":users[0].HeightOfHighClouds3,
            "CLCODEOfHighClouds":users[0].CLCODEOfHighClouds,
            "CLCODEOfHighClouds2":users[0].CLCODEOfHighClouds2,
            "CLCODEOfHighClouds3":users[0].CLCODEOfHighClouds3,
            "CloudSearchLightReading":users[0].CloudSearchLightReading,
            "Rainfall":users[0].Rainfall,
            "Dry_Bulb":users[0].Dry_Bulb,
             "Wet_Bulb":users[0].Wet_Bulb,
              "Max_Read":users[0].Max_Read,
               "Max_Reset":users[0].Max_Reset,
               "Min_Read":users[0].Min_Read,
               "Min_Reset":users[0].Min_Reset,
               "Piche_Read":users[0].Piche_Read,
               "Piche_Reset":users[0].Piche_Reset,
               "TimeMarksThermo": users[0].TimeMarksThermo,
               "TimeMarksHygro":users[0].TimeMarksHygro,
               "TimeMarksRainRec":users[0].TimeMarksRainRec ,
                "Present_Weather":users[0].Present_Weather,
                "Visibility":users[0].Visibility,
               "Wind_Direction":users[0].Wind_Direction,
               "Wind_Speed": users[0].Wind_Speed,
               "Gusting":users[0].Gusting,
               "AttdThermo":users[0].AttdThermo,
               "PrAsRead":users[0].PrAsRead,
               "Correction":users[0].Correction,
               "clp":users[0].CLP,
               "MSLPr":users[0].MSLPr,
               "TimeMarksBarograph":users[0].TimeMarksBarograph,
               "TimeMarksAnemograph":users[0].TimeMarksAnemograph,
               "OtherTMarks":users[0].OtherTMarks,
               "Remarks":users[0].Remarks,
               "sunduration":users[0].sunduration,
               "windrun":users[0].windrun,
               "specitime":users[0].specitime,
               "SubmittedBy":"1221" ,
               "DeviceType":"desktop"
        };

        $scope.sendDataOnline($scope.observationData);


        //alert( $scope.totalamountofallclouds_observationslipform + "nkwagala");
    })








}

  $scope.sendDataOnline = function(data_array){


        $http({
       method : "POST",
       url : "http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/observationformScript.php",
       data: data_array,
      headers: {'Content-Type': 'application/x-www-form-urlencoded'}
      }).then(function mySuccess(response) {
      // $scope.myWelcome = response.data;
      alert("Success"+response.data.message);
      }, function myError(response) {
       //$scope.myWelcome = response.statusText;
      alert("Error"+JSON.stringify(response) );
      });

  }

  $scope.openModalMoreData = function(data_tracked){
    ////alert($scope.selectObservation(data_tracked)[0] + "shows now")
    $scope.selectmoredata(data_tracked, function (users){

        //alert("item picked" + users[0].StationName)
    //  $scope.observationData = users;
        //  $scope.openme(users);
          ////alert(users.length);
          /*$scope.moreform.date=new Date(users[0].date),
          $scope.moreform.StationNumber ="users[0].StationName";,
          $scope.moreform.StationNumber= users[0].StationNumber,
            $scope.moreform.time=users[0].time_observationslipform,
             $scope.moreform.UnitofWindSpeed=users[0].UnitofWindSpeed,
              $scope.moreform.Indoromissionofprecipitation=users[0].Indoromissionofprecipitation,
            $scope.moreform.Typeofstationpresentpastweather=users[0].Typeofstationpresentpastweather,
            $scope.moreform.HeightOfLowestCloud=users[0].HeightOfLowestCloud,
            $scope.moreform.DurationOfPeriodOfPrecipitation=users[0].DurationOfPeriodOfPrecipitation,
            $scope.moreform.Standardisobaricsurface=users[0].Standardisobaricsurface,
            $scope.moreform.PastWeather=users[0].PastWeather,
            $scope.moreform.GrassMininumtemperature=users[0].GrassMininumtemperature,
            $scope.moreform.CharacterandIntensityofPrecipitation=users[0].CharacterandIntensityofPrecipitation ,
            $scope.moreform.BeginningorEndofPrecipitation=users[0].BeginningorEndofPrecipitation,
            $scope.moreform.Indicatoroftypeofintrumentation=users[0].Indicatoroftypeofintrumentation,
            $scope.moreform.DurationofSunshine=users[0].DurationofSunshine,
            $scope.moreform.SignofPressureChange=users[0].SignofPressureChange ,
            $scope.moreform.SupplementaryInformation=users[0].SupplementaryInformation,
            $scope.moreform.VapourPressure=users[0].VapourPressure,
            $scope.moreform.thgraph=users[0].thgraph
*/
              $scope.fillmodalmore(users[0].id);





          //alert( $scope.totalamountofallclouds_observationslipform + "nkwagala");
      })


    //$scope.totalamountofallclouds_observationslipform =   $scope.selectObservation(data_tracked)[0];

    //$scope.totalamountofallclouds_observationslipform = data_tracked;
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var btn = document.getElementById("edit");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal

          modal.style.display = "block";


        span.onclick = function() {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }


        ////alert("click to update entries")


  }












$scope.openModal = function(data_tracked){
  ////alert($scope.selectObservation(data_tracked)[0] + "shows now")
  $scope.selectObservation(data_tracked, function (users){
  //  $scope.observationData = users;
      //  $scope.openme(users);
        ////alert(users.length);


         $scope.obv.date = new Date(users[0].Date)
          $scope.obv.station_observationslipform = users[0].StationName
           $scope.obv.stationNo_observationslipform = users[0].StationNumber
            $scope.obv.time_observationslipform = users[0].TIME;//new Date(users[0].TIME)
            $scope.obv.totalamountofallclouds_observationslipform = users[0].TotalAmountOfAllClouds
            $scope.obv.totalamountoflowclouds_observationslipform = users[0].TotalAmountOfLowClouds
            $scope.obv.TypeOfLowClouds1_observationslipform = users[0].TypeOfLowClouds
            $scope.obv.TypeOfLowClouds2_observationslipform = users[0].TypeOfLowClouds2
            $scope.obv.TypeOfLowClouds3_observationslipform = users[0].TypeOfLowClouds3
            $scope.obv.OktasOfLowClouds1_observationslipform = users[0].OktasOfLowClouds
            $scope.obv.OktasOfLowClouds2_observationslipform = users[0].OktasOfLowClouds2
            $scope.obv.OktasOfLowClouds3_observationslipform = users[0].OktasOfLowClouds3
            $scope.obv.HeightLowClouds1_observationslipform= users[0].HeightOfLowClouds
            $scope.obv.HeightLowClouds2_observationslipform= users[0].HeightOfLowClouds2
            $scope.obv.HeightLowClouds3_observationslipform= users[0].HeightOfLowClouds3
            $scope.obv.CLCODEOfLowClouds1_observationslipform = users[0].CLCODEOfLowClouds
            $scope.obv.CLCODEOfLowClouds2_observationslipform = users[0].CLCODEOfLowClouds2
            $scope.obv.CLCODEOfLowClouds3_observationslipform = users[0].CLCODEOfLowClouds3
            $scope.obv.TypeOfMediumClouds1_observationslipform = users[0].TypeOfMediumClouds
            $scope.obv.TypeOfMediumClouds2_observationslipform = users[0].TypeOfMediumClouds2
            $scope.obv.TypeOfMediumClouds3_observationslipform = users[0].TypeOfMediumClouds3
            $scope.obv.OktasOfMediumClouds1_observationslipform = users[0].OktasOfMediumClouds
            $scope.obv.OktasOfMediumClouds2_observationslipform = users[0].OktasOfMediumClouds2
            $scope.obv.OktasOfMediumClouds3_observationslipform = users[0].OktasOfMediumClouds3
            $scope.obv.HeightOfMediumClouds1_observationslipform = users[0].HeightOfMediumClouds
            $scope.obv.HeightOfMediumClouds2_observationslipform = users[0].HeightOfMediumClouds2
            $scope.obv.HeightOfMediumClouds3_observationslipform = users[0].HeightOfMediumClouds3
            $scope.obv.CLCODEOfMediumClouds1_observationslipform = users[0].CLCODEOfMediumClouds
            $scope.obv.CLCODEOfMediumClouds2_observationslipform = users[0].CLCODEOfMediumClouds2
            $scope.obv.CLCODEOfMediumClouds3_observationslipform = users[0].CLCODEOfMediumClouds3
            $scope.obv.TypeOfHighClouds1_observationslipform = users[0].TypeOfHighClouds
            $scope.obv.TypeOfHighClouds2_observationslipform = users[0].TypeOfHighClouds2
            $scope.obv.TypeOfHighClouds3_observationslipform = users[0].TypeOfHighClouds3
            $scope.obv.OktasOfHighClouds1_observationslipform = users[0].OktasOfHighClouds
            $scope.obv.OktasOfHighClouds2_observationslipform = users[0].OktasOfHighClouds2
            $scope.obv.OktasOfHighClouds3_observationslipform = users[0].OktasOfHighClouds3
            $scope.obv.HeightOfHighClouds1_observationslipform = users[0].HeightOfHighClouds
            $scope.obv.HeightOfHighClouds2_observationslipform = users[0].HeightOfHighClouds2
            $scope.obv.HeightOfHighClouds3_observationslipform = users[0].HeightOfHighClouds3
            $scope.obv.CLCODEOfHighClouds1_observationslipform = users[0].CLCODEOfHighClouds
            $scope.obv.CLCODEOfHighClouds2_observationslipform = users[0].CLCODEOfHighClouds2
            $scope.obv.CLCODEOfHighClouds3_observationslipform = users[0].CLCODEOfHighClouds3
            $scope.obv.cloudsearchlight_observationslipform = users[0].CloudSearchLightReading
            $scope.obv.rainfall_observationslipform = users[0].Rainfall
            $scope.obv.drybulb_observationslipform = users[0].Dry_Bulb
            $scope.obv.wetbulb_observationslipform = users[0].Wet_Bulb
            $scope.obv.maxRead_observationslipform = users[0].Max_Read
            $scope.obv.maxReset_observationslipform = users[0].Max_Reset
            $scope.obv.minRead_observationslipform = users[0].Min_Read
            $scope.obv.minReset_observationslipform = users[0].Min_Reset
            $scope.obv.picheRead_observationslipform = users[0].Piche_Read
          $scope.obv.picheReset_observationslipform = users[0].Piche_Reset
            $scope.obv.timemarksThermo_observationslipform = users[0].TimeMarksThermo
            $scope.obv.timemarksHygro_observationslipform = users[0].TimeMarksHygro
            $scope.obv.timemarksRainRec_observationslipform = users[0].TimeMarksRainRec
            $scope.obv.presentweather_observationslipform = users[0].Present_Weather
            $scope.obv.visibility_observationslipform = users[0].Visibility
            $scope.obv.winddirection_observationslipform = users[0].Wind_Direction
            $scope.obv.windspeed_observationslipform = users[0].Wind_Speed
            $scope.obv.gusting_observationslipform = users[0].Gusting
            $scope.obv.attdThermo_observationslipform = users[0].AttdThermo
            $scope.obv.prAsRead_observationslipform = users[0].PrAsRead
            $scope.obv.correction_observationslipform = users[0].Correction
            $scope.obv.CLP_observationslipform = users[0].CLP
            $scope.obv.MSLPR_observationslipform = users[0].MSLPr
            $scope.obv.timeMarksBarograph_observationslipform = users[0].TimeMarksBarograph
            $scope.obv.timeMarksAnemograph_observationslipform = users[0].TimeMarksAnemograph
            $scope.obv.otherTMarks_observationslipform = users[0].OtherTMarks
            $scope.obv.remarks_observationslipform = users[0].Remarks
            $scope.obv.sunshineduration = users[0].sunduration
            $scope.obv.specitime = users[0].specitime
            $scope.obv.windrun = users[0].windrun

            $scope.fillmodal(users[0].id);





        //alert( $scope.totalamountofallclouds_observationslipform + "nkwagala");
    })


  //$scope.totalamountofallclouds_observationslipform =   $scope.selectObservation(data_tracked)[0];

  //$scope.totalamountofallclouds_observationslipform = data_tracked;
  var modal = document.getElementById('myModal');

  // Get the button that opens the modal
  var btn = document.getElementById("edit");

  // Get the <span> element that closes the modal
  var span = document.getElementsByClassName("close")[0];

  // When the user clicks the button, open the modal

        modal.style.display = "block";


      span.onclick = function() {
          modal.style.display = "none";
      }

      // When the user clicks anywhere outside of the modal, close it
      window.onclick = function(event) {
          if (event.target == modal) {
              modal.style.display = "none";
          }
      }


      ////alert("click to update entries")


}
$scope.fillmodalmore = function(record_id){
    //alert("am trying to run");

    var content_in_modal = "";

    content_in_modal += '<div class="" ng-show="moreformpart1" >'+

'<table class="table table-bordered">'+

  '<thead>'+

      '<tr>'+

          '<th colspan="12" class="head-center"><div class="">'+
'<ol class="progress-meter">'+
'<li class="progress-point done">Cloud entries</li><li class="progress-point todo">Screen entries </li>'+
'</ol>'+
'</div></th>'+


      '</tr>'+

  '</thead>'+

  '<tbody>'+

    '<tr>'+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon">Select Date</span>'+
                '<input type="date" name="date_observationslipform" ng-model="moreform.date" required class="form-control" placeholder="Enter select date" >'+

            '</div>'+
            '<span ng-hide="daterequired" class="validator">Date required please</span>'+
          '</div>'+

      '</td>'+
      '<td colspan="6">'+

        '<div class="form-group col-xs-12">'+
          '<div class="input-group bootstrap-timepicker timepicker">'+
            '<span class="input-group-addon">TIME</span>'+
            '<input id="timepicker1" type="text"  ng-model="moreform.time_observationslipform" class="form-control input-small">'+
            '<span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>'+
          '</div>'+
          '<span ng-hide="Timerequired" class="validator">Time required please</span>'+
        '</div>'+



      '</td>'+
    '</tr>'+

    '<tr>'+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon">Station Name</span>'+
                '<input type="text" id="station_moreform" ng-model="moreform.stationName" required class="form-control"   readonly class="form-control" >'+
                '<input type="hidden" id="station_observationslipform" ng-model="obv.station_observationslipform" required class="form-control"   readonly class="form-control" >'+
                '<input type="hidden" id="stationNo_observationslipform" ng-model="obv.stationNo_observationslipform" required class="form-control"   readonly class="form-control" >'+

            '</div>'+
        '</div>'+
      '</td>'+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon"> Station Number</span>'+
                '<input type="text" id="stationNo_moreform" ng-model="moreform.stationNumber" required class="form-control"  readonly class="form-control"  readonly="readonly" >'+
            '</div>'+
        '</div>'+
      '</td>'+
    '</tr>'+

      '<tr><td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">Unit of Wind Speed</span>'+
                  '<input type="number" name="UnitofWindSpeed"  ng-model="moreform.UnitofWindSpeed"   class="form-control input-size" >'+

          '</div>'+
        '</div>'+
          '</td>'+
        '<td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">Ind. or omission of precipitation</span>'+
                  '<input type="number" name="Indoromissionofprecipitation"  ng-model="moreform.Indoromissionofprecipitation"   class="form-control input-size" >'+

          '</div>'+
        '</div>'+

        '</td>'+
      '</tr>'+
      '<tr><td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">Typeofstationpresentpastweather</span>'+
                  '<input type="number" name="Typeofstationpresentpastweather"  ng-model="moreform.Typeofstationpresentpastweather"   class="form-control input-size" >'+

          '</div>'+
        '</div>'+
          '</td>'+
        '<td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">HeightOfLowestCloud</span>'+
                  '<input type="number" name="HeightOfLowestCloud"  ng-model="moreform.HeightOfLowestCloud"   class="form-control input-size" >'+

          '</div>'+
        '</div>'+

        '</td>'+
      '</tr>'+
      '<tr><td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">Standard isobaric surface</span>'+
                  '<input type="number" name="Standardisobaricsurface"  ng-model="moreform.Standardisobaricsurface"   class="form-control input-size" >'+

          '</div>'+
        '</div>'+
          '</td>'+
          '<td colspan="6">'+
              '<div class="form-group col-xs-12">'+
                  '<div class="input-group">'+
                      '<span class="input-group-addon">Duration Of Period Of Precipitation</span>'+
                      '<input type="number" name="DurationOfPeriodOfPrecipitation"  ng-model="moreform.DurationOfPeriodOfPrecipitation"   class="form-control input-size" >'+

              '</div>'+
            '</div>'+
              '</td>'+
      '</tr>'+
      '<tr>'+
        '<td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">Past Weather</span>'+
                  '<input type="number" name="PastWeather"  ng-model="moreform.PastWeather"   class="form-control input-size" >'+

          '</div>'+
        '</div>'+

        '</td>'+
        '<td colspan="6">'+
          '<div class="form-group col-xs-12">'+
  '<div class="input-group">'+
                  '<span class="input-group-addon">Grass Mininum temperature</span>'+
                  '<input type="number" name="GrassMininumtemperature" ng-model="moreform.GrassMininumtemperature"  class="form-control" placeholder="Enter Grass Mininum temperature" >'+

'</div>'+
              '<span ng-hide="DryBulbrequired" class="validator">input needed</span>'+
          '</div>'+

        '</td>'+
      '</tr>'+
  '</tbody>'+

'</table>'+
'<div class="modal-footer clearfix">'+

      '<button type="submit" ng-model="moreform.postObservationSlipFormData_button" ng-click="openobvView(\'moreformpart2\')" name="postObservationSlipFormData_button" class="btn btn-primary button-size pull-right"><i class="fa fa-plus"></i> Next</button>'+

'</div>'+


    '</div>'+
    '<div class="row observation-form"  ng-show="moreformpart2">'+

  '<table class="table table-bordered">'+

    '<thead>'+

        '<tr>'+

            '<th colspan="12" class="head-center">'+
              '<div class="">'+
                '<ol class="progress-meter">'+
                  '<li class="progress-point done">Grass Mininum temperature</li><li class="progress-point done">Screen entries </li>'+
                '</ol>'+
              '</div>'+
              '</th>'+


        '</tr>'+

    '</thead>'+

    '<tbody>'+
      '<tr>'+

        '<td colspan="6">'+
                      '<div class="form-group col-xs-12">'+
                            '<div class="input-group">'+
                                '<span class="input-group-addon">Character and Intensity of Precipitation</span>'+
                                '<input type="number" name="CharacterandIntensityofPrecipitation" ng-model="moreform.CharacterandIntensityofPrecipitation"  class="form-control" placeholder="Enter Character and Intensity of Precipitation" >'+

                            '</div>'+
                            '<span ng-hide="CharacterandIntensityofPrecipitationbrequired" class="validator">input needed</span>'+

                        '</div>'+
        '</td>'+
        '<td colspan="4">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">Beginning or End of Precipitation</span>'+
                  '<input type="number" name="BeginningorEndofPrecipitation"  ng-model="moreform.BeginningorEndofPrecipitation"   class="form-control" placeholder="Enter BeginningorEndofPrecipitation" >'+
              '</div>'+
          '</div>'+



        '</td>'+
      '</tr>'+



          '<td colspan="4">'+
            '<div class="form-group col-xs-12">'+
                '<div class="input-group">'+
                    '<span class="input-group-addon"> Indicator of type of intrumentation</span>'+
                    '<input type="number" name="Indicatoroftypeofintrumentation" ng-model="moreform.Indicatoroftypeofintrumentation"  class="form-control" placeholder="Enter Indicator of type of intrumentation" >'+
                '</div>'+
            '</div>'+


          '</td>'+
          '<td colspan="4">'+
            '<div class="form-group col-xs-12">'+
                '<div class="input-group">'+
                    '<span class="input-group-addon">GPM</span>'+
                    '<input type="number" name="gpm" ng-model="moreform.gpm"   class="form-control" placeholder="Enter gpm" >'+
                '</div>'+
            '</div>'+
          '</td>'+
        '</tr>'+
        '<tr>'+

          '<td colspan="4">'+
            '<div class="form-group col-xs-12">'+
                '<div class="input-group">'+
                    '<span class="input-group-addon">Sign of Pressure Change</span>'+
                    '<input type="number" name="SignofPressureChange" ng-model="moreform.SignofPressureChange"   class="form-control" placeholder="Enter Sign of Pressure Change" >'+
                '</div>'+
            '</div>'+
          '</td>'+
          '<td colspan="4">'+
            '<div class="form-group col-xs-12">'+
                '<div class="input-group">'+
                    '<span class="input-group-addon">Supplementary Information</span>'+
                  '  <input type="number" name="SupplementaryInformation" ng-model="moreform.SupplementaryInformation"   class="form-control" placeholder="Enter Supplementary Information" >'+
              '  </div>'+
          '  </div>'+
          '</td>'+
      '  </tr>'+

      '  <tr>'+

          '<td colspan="4">'+
            '<div class="form-group col-xs-12">'+
                '<div class="input-group">'+
                    '<span class="input-group-addon">Vapour Pressure</span>'+
                    '<input type="number" name="VapourPressure" ng-model="moreform.VapourPressure"   class="form-control" placeholder="Enter Sign VapourPressure" >'+
              '  </div>'+
            '</div>'+
          '</td>'+
          '<td colspan="4">'+
            '<div class="form-group col-xs-12">'+
              '  <div class="input-group">'+
                  '  <span class="input-group-addon">TH GRAPH</span>'+
                  '  <input type="number" name="THGRAPH" ng-model="moreform.thgraph"   class="form-control" placeholder="Enter TH GRAPH " >'+
              '  </div>'+
          '  </div>'+
        '  </td>'+
        '</tr>'+

  '  </tbody>'+

  '</table>'+



    '<div class="modal-footer clearfix">'+

      '  <button type="submit" ng-model="moreform.postObservationSlipFormData_button" ng-click="updateMoreDataOffline('+record_id+');openobvView(\'moreformpart1\')" name="postObservationSlipFormData_button" class="btn btn-primary button-size pull-right"><i class="fa fa-plus"></i> submit</button>'+
    '<a href="" class="btn btn-danger button-size pull-left" ng-click="openobvView(\'moreformpart1\')"><i class="fa fa-times"></i> back</a>'+
  '  </div>'+
    '</div>';

    $scope.loadobvpendingview();

    document.getElementById("modalContent").innerHTML = content_in_modal;

    $compile(document.getElementById("myModal"))($scope);

}




  $scope.fillmodal = function(record_id) {
    //alert(record_id);
    var content_in_modal = "";

    content_in_modal += '<div class="" ng-show="observationpart1" >'+
'<table class="table table-bordered">'+
' <thead><tr>'+
        ' <th colspan="12" class="head-center"><div class="">'+
        '     <ol class="progress-meter">'+
        '  <li class="progress-point done">Cloud entries</li><li class="progress-point todo">Screen entries </li><li class="progress-point todo">Office Entries</li><li class="progress-point todo">Outdoor entries</li>'+
        '</ol>'+
          ' </div></th>'+
        ' </tr>'+
' </thead>'+
  ' <tbody>'+
  '   <tr> '+
      ' <td colspan="6">'+
      '<div class="form-group">'+
              ' <div class="input-group col-xs-12">'+
                  ' <span class="input-group-addon">Total amount of all clouds</span>'+
                  ' <input type="text" name="totalamountofallclouds_observationslipform"  ng-model="obv.totalamountofallclouds_observationslipform"  class="form-control" required placeholder=" Enter total amount of all clouds"  value="sssssss">'+

              ' </div> '+
              '<span ng-hide="AllCloudsrequired" class="validator">input needed</span>'+
        '   </div> '+
      ' </td>'+
      ' <td colspan="6"> '+
      '   <div class="form-group"> '+
            ' <div class="input-group col-xs-12"> '+
              '   <span class="input-group-addon">Total amount of low clouds</span> '+
              '   <input type="text" name="totalamountoflowclouds_observationslipform" ng-model="obv.totalamountoflowclouds_observationslipform" class="form-control" required placeholder="Enter total amount of low clouds" > '+
          '   </div>'+
          '<span ng-hide="TotalCloudsrequired" class="validator">input needed</span>'+

        '</div>'+
      '</td>'+
    '</tr>'+
    '<tr>'+

      '<td colspan="6">'+

        '<div class="form-group col-xs-12">'+
          '<div class="input-group bootstrap-timepicker timepicker">'+
            '<span class="input-group-addon">METAR TIME</span>'+
            '<input id="timepicker1" type="text"  ng-model="obv.time_observationslipform" class="form-control input-small">'+
            '<span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>'+
          '</div>'+
      '  </div>'+


    '  </td>'+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12">'+
          '<div class="input-group bootstrap-timepicker timepicker">'+
            '<span class="input-group-addon">SPECI TIME</span>'+
      '<input id="timepicker2" type="text" ng-model="obv.specitime" class="form-control input-small" >'+
      '<span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>'+
          '</div>'+
        '</div>'+

      '</td>'+
    '</tr>'+

    ' <tr> '+
      '<td colspan="4">'+
        '<div class="form-group col-xs-12"> '+
            ' <div class="input-group">'+
                ' <span class="input-group-addon">Station Name</span> '+
                ' <input type="text" name="station_observationslipform" ng-model="obv.station_observationslipform" required class="form-control" value="Makerere"  readonly class="form-control" > '+
            ' </div> '+
        ' </div> '+
      ' </td>'+
      '<td colspan="4">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                ' <span class="input-group-addon"> Station Number</span> '+
                ' <input type="text" name="stationNo_observationslipform" ng-model="obv.stationNo_observationslipform" required class="form-control"  readonly class="form-control" value="400098" readonly="readonly" >'+
            '</div>'+
        '</div>'+
      '</td>'+
      '<td colspan="4">'+
      ' <div class="form-group col-xs-12">'+
        '   <div class="input-group"> '+
              ' <span class="input-group-addon">Select Date</span>'+
              ' <input type="date" name="date_observationslipform" ng-model="obv.date" required class="form-control" placeholder="Enter select date" > '+
            '   <input type="hidden" name="checkduplicateEntryOnAddObservationSlipFormData_hiddentextfield" ng-model="obv.checkduplicateEntryOnAddObservationSlipFormData_hiddentextfield"> '+

          ' </div>'+
          '<span ng-hide="daterequired" class="validator">input needed</span>'+
      ' </div>'+
      '</td>'+
    '</tr>'+
    '<tr>'+
        '<th colspan="4" class="head-center">Low</th>'+
        '<th colspan="4" class="head-center">High</th>'+
        '<th colspan="4" class="head-center">Medium</th>'+
    '</tr>'+
    '<tr>'+
        '<th  colspan="1">type</th>'+
        '<th colspan="1">oktas</th>'+
        '<th colspan="1">height</th>'+
        '<th colspan="1">clcode</th>'+
        '<th  colspan="1">type</th>'+
        '<th colspan="1">oktas</th>'+
        '<th colspan="1">height</th>'+
        '<th colspan="1">clcode</th>'+
        '<th  colspan="1">type</th>'+
        '<th colspan="1">oktas</th>'+
        '<th colspan="1">height</th>'+
        '<th colspan="1">clcode</th>'+
    '</tr>'+
      '<tr>'+
          '<td colspan="1">'+
            '<select  name="TypeOfLowClouds1_observationslipform"  ng-model="obv.TypeOfLowClouds1_observationslipform"   class="form-control col-xs-12"   >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfLowClouds1_observationslipform" ng-model="obv.OktasOfLowClouds1_observationslipform"  class="form-control"  >'+
                '<option value=""></option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfLowClouds1_observationslipform"  ng-model="obv.HeightLowClouds1_observationslipform"   class="form-control input-size" >'+
          '</td>'+
          '<td colspan="1">'+
            '<select  name="CLCODEOfLowClouds1_observationslipform"  ng-model="obv.CLCODEOfLowClouds1_observationslipform"   class="form-control" >'+
                '<option value=""></option>'+
                '<option value="Sc">Sc</option>'+
                '<option value="St">St</option>'+
                '<option value="Cu">Cu</option>'+
                '<option value="Cb">Cb</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="TypeOfMediumClouds1_observationslipform"  ng-model="obv.TypeOfMediumClouds1_observationslipform"   class="form-control"   >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfMediumClouds1_observationslipform" ng-model="obv.OktasOfMediumClouds1_observationslipform"   class="form-control" >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfMediumClouds1_observationslipform"  ng-model="obv.HeightOfMediumClouds1_observationslipform"   class="form-control input-size"  >'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="CLCODEOfMediumClouds1_observationslipform"  ng-model="obv.CLCODEOfMediumClouds1_observationslipform"   class="form-control"  >'+
            '<option value=""></option>'+
            '<option value="Ac">Ac</option>'+
            '<option value="As">As</option>'+
            '<option value="Ns">Ns</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="TypeOfHighClouds1_observationslipform"  ng-model="obv.TypeOfHighClouds1_observationslipform"  class="form-control"   >'+
                '<option value=""></option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
                '<option value="9">9</option>'+
            '</select>'+
          '</td> '+
        '  <td colspan="1">'+
            '<select name="OktasOfHighClouds1_observationslipform" ng-model="obv.OktasOfHighClouds1_observationslipform"   class="form-control"  >'+
                '<option value=""></option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfHighClouds1_observationslipform"  ng-model="obv.HeightOfHighClouds1_observationslipform"   class="form-control input-size" >'+
          '</td>'+
          '<td colspan="1">'+
                          '  <select name="CLCODEOfHighClouds1_observationslipform"  ng-model="obv.CLCODEOfHighClouds1_observationslipform" class="form-control" >'+
                                '<option value=""></option>'+
                                '<option value="Cl">Cl</option>'+
                                '<option value="Cc">Cc</option>'+
                                '<option value="Cs">Cs</option>'+
                            '</select>'+
          '</td>'+
      '</tr>'+
      '<tr>'+
          '<td colspan="1">'+
            '<select  name="TypeOfLowClouds2_observationslipform"  ng-model="obv.TypeOfLowClouds2_observationslipform"  class="form-control"   >'+
              '  <option value=""></option>'+
              '  <option value="0">0</option>'+
              '  <option value="1">1</option>'+
              '  <option value="2">2</option>'+
                '<option value="3">3</option>'+
              '  <option value="4">4</option>'+
              '  <option value="5">5</option>'+
              '  <option value="6">6</option>'+
              '  <option value="7">7</option>'+
              '  <option value="8">8</option> '+
              '  <option value="9">9</option>'+
            '</select>'+
          '</td>'+
            '<td colspan="1">'+
            '<select name="OktasOfLowClouds2_observationslipform" ng-model="obv.OktasOfLowClouds2_observationslipform"  class="form-control"  >'+
                '<option value=""> </option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfLowClouds2_observationslipform"  ng-model="obv.HeightLowClouds2_observationslipform"   class="form-control input-size" >'+
          '</td>'+
          '<td colspan="1">'+
            '<select  name="CLCODEOfLowClouds2_observationslipform"  ng-model="obv.CLCODEOfLowClouds2_observationslipform"   class="form-control" >'+
                '<option value=""></option>'+
                '<option value="Sc">Sc</option>'+
                '<option value="St">St</option>'+
                '<option value="Cu">Cu</option>'+
                '<option value="Cb">Cb</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="TypeOfMediumClouds2_observationslipform"  ng-model="obv.TypeOfMediumClouds2_observationslipform"   class="form-control"   >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfMediumClouds2_observationslipform" ng-model="obv.OktasOfMediumClouds2_observationslipform"   class="form-control" >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfMediumClouds2_observationslipform"  ng-model="obv.HeightOfMediumClouds2_observationslipform"   class="form-control input-size"  >'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="CLCODEOfMediumClouds2_observationslipform"  ng-model="obv.CLCODEOfMediumClouds2_observationslipform"   class="form-control"  >'+
            '<option value=""></option>'+
            '<option value="Ac">Ac</option>'+
            '<option value="As">As</option>'+
            '<option value="Ns">Ns</option>'+
            '</select>  '+
          '</td>'+
          '<td colspan="1">'+
            '<select name="TypeOfHighClouds2_observationslipform"  ng-model="obv.TypeOfHighClouds2_observationslipform"  class="form-control"   >'+
                '<option value=""></option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
                '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfHighClouds2_observationslipform" ng-model="obv.OktasOfHighClouds2_observationslipform"   class="form-control"  >'+
                '<option value=""></option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfHighClouds2_observationslipform"  ng-model="obv.HeightOfHighClouds2_observationslipform"   class="form-control input-size" >'+
          '</td>'+
          '<td colspan="1">'+
                            '<select name="CLCODEOfHighClouds2_observationslipform"  ng-model="obv.CLCODEOfHighClouds2_observationslipform" class="form-control" > '+
                                '<option value=""></option>'+
                                '<option value="Cl">Cl</option>'+
                                '<option value="Cc">Cc</option>'+
                                '<option value="Cs">Cs</option>'+
                            '</select>'+
          '</td>'+
      '</tr>'+
      '<tr>'+
          '<td colspan="1">'+
            '<select  name="TypeOfLowClouds3_observationslipform"  ng-model="obv.TypeOfLowClouds3_observationslipform"   class="form-control col-xs-12"   >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfLowClouds3_observationslipform" ng-model="obv.OktasOfLowClouds3_observationslipform"  class="form-control"  >'+
                '<option value=""> </option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfLowClouds3_observationslipform"  ng-model="obv.HeightLowClouds3_observationslipform"   class="form-control input-size" >'+
          '</td>'+
          '<td colspan="1">'+
            '<select  name="CLCODEOfLowClouds3_observationslipform"  ng-model="obv.CLCODEOfLowClouds3_observationslipform"   class="form-control" >'+
                '<option value=""></option>'+
                '<option value="Sc">Sc</option>'+
                '<option value="St">St</option>'+
                '<option value="Cu">Cu</option>'+
                '<option value="Cb">Cb</option>'+

            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="TypeOfMediumClouds3_observationslipform"  ng-model="obv.TypeOfMediumClouds3_observationslipform"   class="form-control"   >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfMediumClouds3_observationslipform" ng-model="obv.OktasOfMediumClouds3_observationslipform"   class="form-control" >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfMediumClouds3_observationslipform"  ng-model="obv.HeightOfMediumClouds3_observationslipform"   class="form-control input-size"  >'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="CLCODEOfMediumClouds3_observationslipform"  ng-model="obv.CLCODEOfMediumClouds3_observationslipform"   class="form-control"  >'+
            '<option value=""></option>'+
            '<option value="Ac">Ac</option>'+
            '<option value="As">As</option>'+
            '<option value="Ns">Ns</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
          '  <select name="TypeOfHighClouds3_observationslipform"  ng-model="obv.TypeOfHighClouds3_observationslipform"  class="form-control"   >'+
              '  <option value=""></option>'+
              '  <option value="0">0</option>'+
              '  <option value="1">1</option> '+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
                '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfHighClouds3_observationslipform" ng-model="obv.OktasOfHighClouds3_observationslipform"   class="form-control"  >'+
                '<option value=""></option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfHighClouds3_observationslipform"  ng-model="obv.HeightOfHighClouds3_observationslipform"   class="form-control input-size" >'+

          '</td>'+
          '<td colspan="1">'+
                            '<select name="CLCODEOfHighClouds3_observationslipform"  ng-model="obv.CLCODEOfHighClouds3_observationslipform" class="form-control" >'+
                                '<option value=""></option>'+
                                '<option value="Cl">Cl</option>'+
                              '  <option value="Cc">Cc</option>'+
                              '  <option value="Cs">Cs</option>'+
                          '  </select>'+
        '  </td>'+
      '</tr>'+
      '<tr><td colspan="6">'+
          '<div class="form-group col-xs-12">'+
          '    <div class="input-group">'+
          '        <span class="input-group-addon">CloudSearchLight Reading</span>'+
          '        <input type="number" name="cloudsearchlight_observationslipform"  ng-model="obv.cloudsearchlight_observationslipform"   class="form-control input-size" >'+

          '</div>'+
        '</div>'+
        '  </td>'+
        '<td colspan="6">'+
        '  <div class="form-group col-xs-12">'+
        '      <div class="input-group">'+
        '          <span class="input-group-addon">Rainfall</span>'+
                  '<input type="number" name="rainfall_observationslipform"  ng-model="obv.rainfall_observationslipform"   class="form-control input-size" >'+

          '</div>'+
        '</div>'+

      '  </td>'+
      '</tr>'+
  '</tbody>'+
'</table>'+
'<div class="modal-footer clearfix">'+
      '<button type="submit" ng-model="obv.postObservationSlipFormData_button" ng-click="openobvView(\'observationpart2\')" name="postObservationSlipFormData_button" class="btn btn-primary button-size pull-right"><i class="fa fa-plus"></i> Next</button> '+
'</div></div>';


content_in_modal +=   '<div class="row observation-form"  ng-show="observationpart2">'+
'<table class="table table-bordered">'+

  '<thead>'+

      '<tr>'+

          '<th colspan="12" class="head-center"><div class="">'+
          '<ol class="progress-meter">'+
          '<li class="progress-point done">Cloud entries</li><li class="progress-point done">Screen entries </li><li class="progress-point todo">Office Entries</li><li class="progress-point todo">Outdoor entries</li>'+
          '</ol>'+
            '</div></th>'+


      '</tr>'+

  '</thead>'+

  '<tbody>'+
    '<tr>'+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon">Dry Bulb</span>'+
                '<input type="text" name="drybulb_observationslipform" ng-model="obv.drybulb_observationslipform"  class="form-control" placeholder="Enter Dry Bulb" >'+
            '</div>'+
              '<span ng-show="DryBulbrequired" class="validator">input needed</span>'+
        '</div>'+

      '</td>'+
      '<td colspan="6">'+
                  '  <div class="form-group col-xs-12">'+
                          '<div class="input-group">'+
                              '<span class="input-group-addon">Wet Bulb</span>'+
                              '<input type="text" name="wetbulb_observationslipform" ng-model="obv.wetbulb_observationslipform"  class="form-control" placeholder="Enter Wet Bulb" >'+
                        '  </div>'+
                        '<span ng-show="WetBulbrequired" class="validator">input needed</span>'+
                    '  </div>'+
      '</td>'+
    '</tr>'+

    '<tr>'+

        '<th colspan="4" class="head-center">MAX</th>'+

        '<th colspan="4" class="head-center">MIN</th>'+

        '<th colspan="4" class="head-center">PICHE</th>'+

'        </tr>'+
      '<tr>'+
          '<td colspan="4">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon"> Read</span>'+
                  '<input type="text" name="maxRead_observationslipform"  ng-model="obv.maxRead_observationslipform"  class="form-control" placeholder="Enter MAX READ" >'+
              '</div>'+
          '</div>'+

          '<div class="form-group col-xs-12">'+
                  '<div class="input-group">'+
                      '<span class="input-group-addon"> Reset</span>'+
                      '<input type="text" name="maxReset_observationslipform" ng-model="obv.maxReset_observationslipform"  class="form-control" placeholder="Enter MAX RESET" >'+
                  '</div>'+
            '  </div>'+
            '</td> '+
          '<td colspan="4">'+
            '<div class="form-group col-xs-12"> '+
                '<div class="input-group"> '+
                    '<span class="input-group-addon"> Read</span>'+
                  '  <input type="text" name="minRead_observationslipform"  ng-model="obv.minRead_observationslipform"   class="form-control" placeholder="Enter MIN READ" >'+
              '  </div>'+
            '</div>'+

            '<div class="form-group col-xs-12">'+
                '<div class="input-group">'+
                    '<span class="input-group-addon"> Reset</span>'+
                    '<input type="text" name="minReset_observationslipform" ng-model="obv.minReset_observationslipform"   class="form-control" placeholder="Enter MIN RESET" >'+
                '</div>'+
            '</div>'+
          '</td>'+
          '<td colspan="4">'+
            '<div class="form-group col-xs-12">'+
                '<div class="input-group">'+
                    '<span class="input-group-addon"> Read</span> '+
                    '<input type="text" name="picheRead_observationslipform"  ng-model="obv.picheRead_observationslipform"   class="form-control" placeholder="Enter PICHE READ" >'+
                '</div>'+
            '</div>'+
'<div class="form-group col-xs-12">'+
                '<div class="input-group">'+
                    '<span class="input-group-addon"> Reset</span>'+
                    '<input type="text" name="picheReset_observationslipform" ng-model="obv.picheReset_observationslipform"   class="form-control" placeholder="Enter PICHE RESET" >'+
                '</div>'+
            '</div>'+
          '</td>'+

      '</tr>'+
      '<tr>'+
        '<th colspan="12" class="head-center">Time marks</th>'+
      '</tr>'+
      '<tr>'+
        '<td colspan="4">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">THERMO</span>'+
                  '<input type="text" name="timemarksThermo_observationslipform"  ng-model="obv.timemarksThermo_observationslipform"   class="form-control" placeholder="Enter TIME MARKS THERMO" >'+
              '</div>'+
          '</div>'+
        '</td>'+
        '<td colspan="4">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon"> HYGRO</span>'+
                  '<input type="text" name="timemarksHygro_observationslipform" ng-model="obv.timemarksHygro_observationslipform"  class="form-control" placeholder="Enter TIME MARKS HYGRO" >'+
              '</div>'+
'              </div>'+
  '</td>'+
        '<td colspan="4">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">RAIN REC</span>'+
                  '<input type="text" name="timemarksRainRec_observationslipform" ng-model="obv.timemarksRainRec_observationslipform"   class="form-control" placeholder="Enter TIME MARKS RAIN REC" >'+
              '</div>'+
          '</div>'+
        '</td>'+
      '</tr> '+
  '</tbody> '+

'</table>'+
'<div class="modal-footer clearfix">'+

      '<button type="submit" ng-model="obv.postObservationSlipFormData_button" ng-click="openobvView(\'observationpart3\')" name="postObservationSlipFormData_button" class="btn btn-primary button-size pull-right"><i class="fa fa-plus"></i> Next</button>'+
'<a href="" class="btn btn-danger button-size pull-left" ng-click="openobvView(\'observationpart1\')"><i class="fa fa-times"></i> back</a>'+
'</div></div>';


content_in_modal += '<div class="row observation-form" ng-show="observationpart3">'+

'<table class="table table-bordered">'+

'<thead>'+

    '<tr>'+

        '<th colspan="12" class="head-center"><div class="">'+
        '<ol class="progress-meter">'+
        '<li class="progress-point done">Cloud entries</li><li class="progress-point done">Screen entries </li><li class="progress-point done">Office Entries</li><li class="progress-point todo">Outdoor entries</li>'+
        '</ol>'+
        '</div></th>'+


    '</tr>'+

'  </thead>'+

'<tbody>'+

  '  <tr> '+
        '<td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">Attd.Thermo.(C)</span>'+
                  '<input type="text" name="attdThermo_observationslipform" ng-model="obv.attdThermo_observationslipform"  class="form-control" placeholder="Enter ATTD.THERMO" >'+
              '</div>'+
          '</div>'+


          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">Pr.As Read(C)</span>'+
                  '<input type="text" name="prAsRead_observationslipform" ng-model="obv.prAsRead_observationslipform"   class="form-control" placeholder="Enter Pr.As Read" >'+
              '</div> '+
          '</div>'+



          '</td>'+
        '<td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">Correction</span>'+
                  '<input type="text" name="correction_observationslipform" ng-model="obv.correction_observationslipform"   class="form-control" placeholder="Enter Correction" >'+
              '</div>'+
          '</div>'+

          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">C.L.P(mb)</span>'+
                  '<input type="text" name="CLP_observationslipform" ng-model="obv.CLP_observationslipform"   class="form-control" placeholder="Enter C.L.P(mb)" >'+
              '</div>'+
          '</div>'+

        '</td>'+

    '</tr>'+

    '<tr>'+
      '<td colspan="12">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
              '  <span class="input-group-addon">M.S.L.Pr(mb) or 850mb. Ht.(gpm)</span>'+
                '<input type="text" name="MSLPR_observationslipform" ng-model="obv.MSLPR_observationslipform"  class="form-control" placeholder="Enter M.S.L.Pr(mb) or 850mb. Ht.(gpm)" > '+
          '  </div>'+
        '</div>'+
      '</td>'+
    '</tr>'+
    '<tr>'+
      '<th class="head-center" colspan="12">Time marks</th>'+
    '</tr>'+
    '<tr>'+
        '<td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group"> '+
                  '<span class="input-group-addon">TIME MARKS BAROGRAPH</span> '+
                  '<input type="text" name="timeMarksBarograph_observationslipform" ng-model="obv.timeMarksBarograph_observationslipform"  class="form-control" placeholder="Enter TIME MARKS BAROGRAPH" > '+
              '</div>'+
          '</div>'+
        '</td>'+
        '<td colspan="6">'+

                            '<div class="form-group col-xs-12">'+
                                '<div class="input-group">'+
                                    '<span class="input-group-addon">TIME MARKS ANEMOGRAPH</span>'+
                                '  <input type="text" name="timeMarksAnemograph_observationslipform" ng-model="obv.timeMarksAnemograph_observationslipform"   class="form-control" placeholder="Enter TIME MARKS ANEMOGRAPH" > '+
                              '  </div> '+
                '            </div>'+


        '</td>'+
    '</tr>'+
    '<tr>'+
      '<td colspan="12">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon">Other T/MARKS </span>'+
                '<input type="text" name="otherTMarks_observationslipform" ng-model="obv.otherTMarks_observationslipform"  class="form-control" placeholder="Enter Other T/MARKS" >'+
            '</div>'+
        '</div>'+

        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon">Remarks or any other Observations </span>'+
                '<input type="text" name="remarks_observationslipform" ng-model="obv.remarks_observationslipform"  class="form-control" placeholder="Enter Remarks or any other Observations" >'+
          '  </div>'+
        '</div>'+

      '</td>'+
    '</tr>'+
'</tbody>'+

'</table>'+
'<div class="modal-footer clearfix">'+

    '<button type="submit" ng-model="obv.postObservationSlipFormData_button" ng-click="openobvView(\'observationpart4\')" name="postObservationSlipFormData_button" class="btn btn-primary button-size pull-right"><i class="fa fa-plus"></i> Next</button>'+
'<a href="" class="btn btn-danger button-size pull-left" ng-click="openobvView(\'observationpart2\')"><i class="fa fa-times"></i> back</a>'+
'</div></div>';


content_in_modal += '<div class=""  ng-show="observationpart4">'+

'<table class="table table-bordered">'+
'<thead>'+
    '<tr>'+
        '<th colspan="12" class="head-center"><div class="">'+
        '<ol class="progress-meter">'+
        '<li class="progress-point done">Cloud entries</li><li class="progress-point done">Screen entries </li><li class="progress-point done">Office Entries</li><li class="progress-point done">Outdoor entries</li>'+
        '  </ol>'+
          '</div></th>'+
    '</tr>'+
'</thead>'+
'<tbody>'+
  '<tr>'+
    '<td colspan="12">'+
      '<div class="form-group col-xs-12">'+
          '<div class="input-group">'+
              '<span class="input-group-addon">PRESENT WEATHER</span>'+
              '<input type="text" name="presentweather_observationslipform" ng-model="obv.presentweather_observationslipform"   class="form-control" placeholder="Enter PRESENT WEATHER" >'+
          '</div>'+
    '  </div>'+
    '</td>'+

  '</tr>'+
    '<tr>'+
        '<td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">VISIBILITY</span>'+
                  '<input type="text" name="visibility_observationslipform" ng-model="obv.visibility_observationslipform"   class="form-control" placeholder="Enter VISIBILITY" >'+
              '</div>'+
              '<span ng-hide="visibilityrequired" class="validator">input needed</span>          '+
              '</div>'+
          '</td>'+
        '<td colspan="6">'+
                            '<div class="form-group col-xs-12">'+
                                '<div class="input-group">'+
                                    '<span class="input-group-addon">GUSTING(KTS)</span> '+
                                    '<input type="text" name="gusting_observationslipform" ng-model="obv.gusting_observationslipform"   class="form-control" placeholder="Enter GUSTING (KTS)" > '+
                                '</div>'+
                            '</div>'+
        '</td>'+

    '</tr>'+
    '<tr>'+
      '<th colspan="12" class="head-center">wind</th>'+
    '</tr>'+
    '<tr>'+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon">WIND DIRECTION</span>'+
                '<input type="text" name="winddirection_observationslipform" ng-model="obv.winddirection_observationslipform"   class="form-control" placeholder="Enter WIND DIRECTION" > '+
          '  </div>'+
        '  <span ng-hide="directionrequired" class="validator">input needed</span>'+

      '  </div>'+

      '</td>'+
      '<td colspan="6">'+

                        '<div class="form-group col-xs-12">'+
                            '<div class="input-group">'+
                                '<span class="input-group-addon">WIND SPEED(KTS)</span>'+
                                '<input type="text" name="windspeed_observationslipform" ng-model="obv.windspeed_observationslipform"   class="form-control" placeholder="Enter WIND SPEED(KTS)" >'+
                            '</div>'+
                            '  <span ng-hide="speedrequired" class="validator">input needed</span>'+
                        '</div>'+


      '</td>'+

    '</tr>'+
    '<tr>'+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon">SUN DURATION</span>'+
                '<input type="number" placeholder="enter duration period" ng-model="obv.sunshineduration" class="form-control">'+

          '  </div>'+

      '  </div>'+

      '</td>'+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon">WIND RUN</span>'+
                '<input type="number" placeholder="wind run" ng-model="obv.windrun" class="form-control">'+
          '  </div>'+

        '</div>'+

    '  </td>'+
    '</tr>'+
'</tbody>'+

'</table>'+
'  <div class="modal-footer clearfix"> '+

    '<button type="submit" ng-model="obv.postObservationSlipFormData_button" ng-click="updateObservationDataOffline('+record_id+')" name="postObservationSlipFormData_button" class="btn btn-primary button-size pull-right"><i class="fa fa-plus"></i>Update entry</button>'+
'<a href="" class="btn btn-danger button-size pull-left" ng-click="openobvView(\'observationpart3\')"><i class="fa fa-times"></i> back</a>'+
'</div></div>';

$scope.loadobvpendingview();

document.getElementById("modalContent").innerHTML = content_in_modal;

$compile(document.getElementById("myModal"))($scope);


  }

$scope.showDiv2 = function(){
  $scope.observationpart2 = true;
}


$scope.openLine = function(callback, callbackmore){
  if (mydb) {
          var dbdetails = [{name:'', id : ''}];
          var moredetails = [{name:'', id : ''}];
      //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
      mydb.transaction(function (t) {
          t.executeSql("SELECT * FROM obseravation_details__table WHERE SubmittedBy=?", [document.getElementById("useridside").innerHTML],   function(transaction, results) {
              //initialise the listitems variable
              var i;//Iterate through the results
            //  //alert(results.rows.length+ "olibiki")
              for (i = 0; i < results.rows.length; i++) {
                  //Get the current row
                  var row = results.rows.item(i);

                  dbdetails[i] ={ name: row.CreationDate, id: row.id};
                  //dbdetails[i].id = row.CreationDate;
                  //dbdetails.push(row.CreationDate);
                //  //alert(dbdetails.length + "oh God")
              }


              callback(dbdetails);

          });
          t.executeSql("SELECT * FROM moreformTable WHERE SubmittedBy=?", [document.getElementById("useridside").innerHTML],   function(transaction, results) {
              //initialise the listitems variable
              var i;//Iterate through the results
            //  //alert(results.rows.length+ "olibiki")
              for (i = 0; i < results.rows.length; i++) {
                  //Get the current row
                  var row = results.rows.item(i);

                  moredetails[i] ={ name: row.CreationDate, id: row.id};
                  //dbdetails[i].id = row.CreationDate;
                  //dbdetails.push(row.CreationDate);
                //  //alert(dbdetails.length + "oh God")
              }


              callbackmore(moredetails);

          });
      });


 ////alert($scope.arrayObservation[1])
  } else {
      //alert("db not found, your browser does not support web sql!");
  }



  ////alert($scope.arrayObservation[1]);
}

$scope.updateMyList=function(transaction, results) {
    //initialise the listitems variable
    var listitems = "";
    //get the car list holder ul
    var listholder = document.getElementById("mylist");
    //clear cars list ul
    listholder.innerHTML = "";
    var i;//Iterate through the results
    for (i = 0; i < results.rows.length; i++) {
        //Get the current row
        var row = results.rows.item(i);

listholder.innerHTML += "<li>" + row.Date + " - " + row.StationName +"-"+   row.StationNumber + " - "+
      row.TIME + " - "+ row.TotalAmountOfAllClouds + " - "+row.TotalAmountOfLowClouds + " - "+
      row.TypeOfLowClouds + " - "+ row.OktasOfLowClouds + " - "+row.HeightOfLowClouds + " - "+
      row.CLCODEOfLowClouds + " - "+ row.TypeOfMediumClouds + " - "+row.OktasOfMediumClouds + " - "+
      row.HeightOfMediumClouds + " - "+ row.CLCODEOfMediumClouds + " - "+row.TypeOfHighClouds + " - "+
      row.OktasOfHighClouds + "  - "+row.HeightOfMediumClouds + " - "+
      row.TypeOfLowClouds + " - "+ row.HeightOfHighClouds + " - "+row.CLCODEOfHighClouds + " - "+
      row.CloudSearchLightReading + " - "+ row.Rainfall + " - "+row.Dry_Bulb + " - "+
      row.Wet_Bulb + " - "+ row.Max_Read + " - "+row.Max_Reset + " - "+
      row.Min_Read + " - "+ row.Min_Reset + " - "+row.Piche_Read + " - "+
      row.Piche_Reset + " - "+ row.TimeMarksThermo + " - "+row.TimeMarksHygro + " - "+
      row.TimeMarksRainRec + " - "+ row.Present_Weather + " - "+row.Visibility + " - "+
      row.Wind_Direction + " - "+ row.Wind_Speed + " - "+row.Gusting + " - "+
      row.AttdThermo + " - "+ row.PrAsRead + " - "+row.Correction + " - "+
      row.CLP + " - "+ row.MSLPr + " - "+row.TimeMarksBarograph + " - "+
      row.TimeMarksAnemograph + " - "+ row.OtherTMarks + " - "+row.Remarks + " - "+ " - "+row.windrun+ " - "+row.sunduration+ " - "+row.specitime +  row.SubmittedBy + " - "+
      row.CreationDate  + " - "+" (<button type='submit' ng-click='deleteFromOffline("+row.id+");'>Delete Car</button>)";

$compile(document.getElementById("mylist"))($scope);

    }

}

$scope.updateMyList0=function(transaction, results) {

    //initialise the listitems variable
    var listitems = "";
    //get the car list holder ul
    var listholder = document.getElementById("mylist0");
    //clear cars list ul
    listholder.innerHTML = "";
    var i;//Iterate through the results
    alert(results.rows.length)
    for (i = 0; i < results.rows.length; i++) {
        //Get the current row
        var row = results.rows.item(i);


listholder.innerHTML += "<li>" + row.date + " - " + row.StationName +"-"+   row.StationNumber + " - "+
      row.time + " - "+ row.UnitofWindSpeed + " - "+row.Indoromissionofprecipitation + " - "+
      row.Typeofstationpresentpastweather + " - "+ row.HeightOfLowestCloud + " - "+
      row.DurationOfPeriodOfPrecipitation + " - "+ row.Standardisobaricsurface + " - "+row.PastWeather + " - "+
      row.GrassMininumtemperature + " - "+ row.CharacterandIntensityofPrecipitation + " - "+row.BeginningorEndofPrecipitation + " - "+
      row.Indicatoroftypeofintrumentation + " - "+ row.DurationofSunshine + " - "+row.SignofPressureChange + " - "+
      row.SupplementaryInformation + " - "+ row.VapourPressure + " - "+row.thgraph + " - "+
      row.CreationDate  + " - "+" (<button type='submit' ng-click='deleteFromOffline("+row.id+");'>Delete Car</button>)";


$compile(document.getElementById("mylist0"))($scope);

    }

}
 $scope.displayData= function() {
  //check to ensure the mydb object has been created
    if (mydb) {
        //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
        mydb.transaction(function (t) {
            t.executeSql("SELECT * FROM obseravation_details__table", [],   $scope.updateMyList);

        });
    } else {
        alert("db not found, your browser does not support web sql!");
    }
}

$scope.displayData0= function() {
 //check to ensure the mydb object has been created
   if (mydb) {
       //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
       mydb.transaction(function (t) {
           t.executeSql("SELECT * FROM moreformTable", [],   $scope.updateMyList0);

       });
   } else {
       alert("db not found, your browser does not support web sql!");
   }
}
//function to add the car to the database
$scope.updateObservationDataOffline = function(id){
  //check to ensure the mydb object has been created

  if (mydb) {


      var  date=$scope.convertDate($scope.obv.date),
      StationName=$scope.obv.station_observationslipform,
      StationNumber=$scope.obv.stationNo_observationslipform,
        time=$scope.obv.time_observationslipform,
        TotalAmountOfAllClouds=$scope.obv.totalamountofallclouds_observationslipform,
        TotalAmountOfLowClouds=$scope.obv.totalamountoflowclouds_observationslipform,
         TypeOfLowClouds=$scope.obv.TypeOfLowClouds1_observationslipform,
         TypeOfLowClouds2=$scope.obv.TypeOfLowClouds2_observationslipform,
         TypeOfLowClouds3=$scope.obv.TypeOfLowClouds3_observationslipform,
        OktasOfLowClouds=$scope.obv.OktasOfLowClouds1_observationslipform,
        OktasOfLowClouds2=$scope.obv.OktasOfLowClouds2_observationslipform,
        OktasOfLowClouds3=$scope.obv.OktasOfLowClouds3_observationslipform,
         HeightOfLowClouds=$scope.obv.HeightLowClouds1_observationslipform,
         HeightOfLowClouds2=$scope.obv.HeightLowClouds2_observationslipform,
         HeightOfLowClouds3=$scope.obv.HeightLowClouds3_observationslipform,
        CLCODEOfLowClouds=$scope.obv.CLCODEOfLowClouds1_observationslipform,
        CLCODEOfLowClouds2=$scope.obv.CLCODEOfLowClouds2_observationslipform,
        CLCODEOfLowClouds3=$scope.obv.CLCODEOfLowClouds3_observationslipform,
         TypeOfMediumClouds=$scope.obv.TypeOfMediumClouds1_observationslipform,
         TypeOfMediumClouds2=$scope.obv.TypeOfMediumClouds2_observationslipform,
         TypeOfMediumClouds3=$scope.obv.TypeOfMediumClouds3_observationslipform,
        OktasOfMediumClouds=$scope.obv.OktasOfMediumClouds1_observationslipform,
        OktasOfMediumClouds2=$scope.obv.OktasOfMediumClouds2_observationslipform,
        OktasOfMediumClouds3=$scope.obv.OktasOfMediumClouds3_observationslipform,
        HeightOfMediumClouds=$scope.obv.HeightOfMediumClouds1_observationslipform,
        HeightOfMediumClouds2=$scope.obv.HeightOfMediumClouds2_observationslipform,
        HeightOfMediumClouds3=$scope.obv.HeightOfMediumClouds3_observationslipform,
        CLCODEOfMediumClouds=$scope.obv.CLCODEOfMediumClouds1_observationslipform,
        CLCODEOfMediumClouds2=$scope.obv.CLCODEOfMediumClouds2_observationslipform,
        CLCODEOfMediumClouds3=$scope.obv.CLCODEOfMediumClouds3_observationslipform,
        TypeOfHighClouds=$scope.obv.TypeOfHighClouds1_observationslipform,
        TypeOfHighClouds2=$scope.obv.TypeOfHighClouds2_observationslipform,
        TypeOfHighClouds3=$scope.obv.TypeOfHighClouds3_observationslipform,
          OktasOfHighClouds=$scope.obv.OktasOfHighClouds1_observationslipform,
          OktasOfHighClouds2=$scope.obv.OktasOfHighClouds2_observationslipform,
          OktasOfHighClouds3=$scope.obv.OktasOfHighClouds3_observationslipform,
        HeightOfHighClouds=$scope.obv.HeightOfHighClouds1_observationslipform,
        HeightOfHighClouds2=$scope.obv.HeightOfHighClouds2_observationslipform,
        HeightOfHighClouds3=$scope.obv.HeightOfHighClouds3_observationslipform,
        CLCODEOfHighClouds=$scope.obv.CLCODEOfHighClouds1_observationslipform,
        CLCODEOfHighClouds2=$scope.obv.CLCODEOfHighClouds2_observationslipform,
        CLCODEOfHighClouds3=$scope.obv.CLCODEOfHighClouds3_observationslipform,
         CloudSearchLightReading=$scope.obv.cloudsearchlight_observationslipform,
         Rainfall=$scope.obv.rainfall_observationslipform,
         Dry_Bulb=$scope.obv.drybulb_observationslipform,
          Wet_Bulb=$scope.obv.wetbulb_observationslipform,
           Max_Read=$scope.obv.maxRead_observationslipform,
            Max_Reset=$scope.obv.maxReset_observationslipform,
            Min_Read=$scope.obv.minRead_observationslipform,
            Min_Reset=$scope.obv.minReset_observationslipform,
            Piche_Read=$scope.obv.picheRead_observationslipform,
            Piche_Reset=$scope.obv.picheReset_observationslipform,
            TimeMarksThermo=$scope.obv.timemarksThermo_observationslipform,
            TimeMarksHygro=$scope.obv.timemarksHygro_observationslipform,
            TimeMarksRainRec=$scope.obv.timemarksRainRec_observationslipform ,
             Present_Weather=$scope.obv.presentweather_observationslipform,
             Visibility=$scope.obv.visibility_observationslipform,
            Wind_Direction=$scope.obv.winddirection_observationslipform,
            Wind_Speed=$scope.obv.windspeed_observationslipform ,
            Gusting=$scope.obv.gusting_observationslipform,
            AttdThermo=$scope.obv.attdThermo_observationslipform,
            PrAsRead=$scope.obv.prAsRead_observationslipform,
            Correction=$scope.obv.correction_observationslipform,
            clp=$scope.obv.CLP_observationslipform,
            MSLPr=$scope.obv.MSLPR_observationslipform,
            TimeMarksBarograph=$scope.obv.timeMarksBarograph_observationslipform,
            TimeMarksAnemograph=$scope.obv.timeMarksAnemograph_observationslipform,
            OtherTMarks=$scope.obv.otherTMarks_observationslipform,
            Remarks=$scope.obv.remarks_observationslipform,
            sunduration=$scope.obv.sunshineduration,
            windrun=$scope.obv.windrun,
            specitime=$scope.obv.specitime,
            SubmittedBy="", CreationDate = new Date();




      //Test to ensure that the user has entered both a make and model
      if (TotalAmountOfAllClouds !== "" && StationNumber !== "") {

                var query = "UPDATE obseravation_details__table SET Date=?,  StationName=?,  StationNumber=?,  TIME=?,  TotalAmountOfAllClouds=?, TotalAmountOfLowClouds=?, TypeOfLowClouds=?, TypeOfLowClouds2=?, TypeOfLowClouds3=?, OktasOfLowClouds=?, OktasOfLowClouds2=?, OktasOfLowClouds3=?, HeightOfLowClouds=?, HeightOfLowClouds2=?, HeightOfLowClouds3=?, CLCODEOfLowClouds=?, CLCODEOfLowClouds2=?, CLCODEOfLowClouds3=?, TypeOfMediumClouds=?,TypeOfMediumClouds2=?,"+
                "TypeOfMediumClouds3=?, OktasOfMediumClouds=?,OktasOfMediumClouds2=?,OktasOfMediumClouds3=?, HeightOfMediumClouds=?, HeightOfMediumClouds2=?,HeightOfMediumClouds3=?,CLCODEOfMediumClouds=?,CLCODEOfMediumClouds2=?,CLCODEOfMediumClouds3=?,TypeOfHighClouds=?,TypeOfHighClouds2=?,TypeOfHighClouds3=?, OktasOfHighClouds=?, OktasOfHighClouds2=?,OktasOfHighClouds3=?,HeightOfHighClouds=?,HeightOfHighClouds2=?,HeightOfHighClouds3=?, CLCODEOfHighClouds=?, CLCODEOfHighClouds2=?, CLCODEOfHighClouds3=?, CloudSearchLightReading=?, Rainfall=?,Dry_Bulb=?,"+ "Wet_Bulb=?, Max_Read=?, Max_Reset=?,Min_Read=?,  Min_Reset=?,Piche_Read=?,Piche_Reset=?,TimeMarksThermo=?,TimeMarksHygro=?,TimeMarksRainRec =?, Present_Weather=?,Visibility=?,Wind_Direction=?,Wind_Speed =?,Gusting=?,AttdThermo=?,PrAsRead=?,Correction=?,CLP=?,MSLPr=?,TimeMarksBarograph=?,TimeMarksAnemograph=?,OtherTMarks=?,Remarks=?,windrun=?, sunduration=?, specitime=?, SubmittedBy=?,CreationDate=?   WHERE id=?";

      mydb.transaction(function (t) {
        //alert(date+time)
        t.executeSql(query, [date,  StationName,  StationNumber,  time,  TotalAmountOfAllClouds, TotalAmountOfLowClouds, TypeOfLowClouds,TypeOfLowClouds2,TypeOfLowClouds3,
                        OktasOfLowClouds,OktasOfLowClouds2,OktasOfLowClouds3, HeightOfLowClouds,HeightOfLowClouds2,HeightOfLowClouds3, CLCODEOfLowClouds,  CLCODEOfLowClouds2, CLCODEOfLowClouds3,TypeOfMediumClouds,TypeOfMediumClouds2,TypeOfMediumClouds3, OktasOfMediumClouds,  OktasOfMediumClouds2,  OktasOfMediumClouds3, HeightOfMediumClouds, HeightOfMediumClouds2,  HeightOfMediumClouds3,  CLCODEOfMediumClouds,CLCODEOfMediumClouds2,CLCODEOfMediumClouds3,
                         TypeOfHighClouds, TypeOfHighClouds2,TypeOfHighClouds3,OktasOfHighClouds, OktasOfHighClouds2,OktasOfHighClouds3,HeightOfHighClouds,HeightOfHighClouds2,HeightOfHighClouds3, CLCODEOfHighClouds,  CLCODEOfHighClouds2,  CLCODEOfHighClouds3, CloudSearchLightReading, Rainfall,Dry_Bulb, Wet_Bulb,
                         Max_Read, Max_Reset,Min_Read,  Min_Reset,Piche_Read,Piche_Reset,TimeMarksThermo,TimeMarksHygro,TimeMarksRainRec ,
                         Present_Weather,Visibility,Wind_Direction,Wind_Speed ,Gusting,AttdThermo,PrAsRead,Correction,clp,MSLPr,TimeMarksBarograph,TimeMarksAnemograph,OtherTMarks,Remarks,windrun,sunduration, specitime,SubmittedBy, CreationDate, id]);


          alert("The updates have been successfully made")


          });
      } else {
          alert("You must enter a StationNumber and TotalAmountOfAllClouds!");
      }
  } else {
      alert("db not found, your browser does not support web sql!");
  }


document.getElementById("myModal").style.display = "none";
}


$scope.updateMoreDataOffline = function(id){
  //check to ensure the mydb object has been created

  if (mydb) {

            var  date=$scope.convertDate($scope.moreform.date),
            StationName=$scope.moreform.station_observationslipform,
            StationNumber=$scope.moreform.station_observationslipform,
              time=$scope.moreform.time_observationslipform,
               UnitofWindSpeed=$scope.moreform.UnitofWindSpeed,
                Indoromissionofprecipitation=$scope.moreform.Indoromissionofprecipitation,
                Typeofstationpresentpastweather=$scope.moreform.Typeofstationpresentpastweather,
                HeightOfLowestCloud=$scope.moreform.HeightOfLowestCloud,
                DurationOfPeriodOfPrecipitation=$scope.moreform.DurationOfPeriodOfPrecipitation,
                Standardisobaricsurface=$scope.moreform.Standardisobaricsurface,
                PastWeather=$scope.moreform.PastWeather,
                GrassMininumtemperature=$scope.moreform.GrassMininumtemperature,
                CharacterandIntensityofPrecipitation=$scope.moreform.CharacterandIntensityofPrecipitation ,
                BeginningorEndofPrecipitation=$scope.moreform.BeginningorEndofPrecipitation,
                Indicatoroftypeofintrumentation=$scope.moreform.Indicatoroftypeofintrumentation,
                DurationofSunshine=$scope.moreform.DurationofSunshine,
                SignofPressureChange=$scope.moreform.SignofPressureChange ,
                SupplementaryInformation=$scope.moreform.SupplementaryInformation,
                VapourPressure=$scope.moreform.VapourPressure,
                thgraph=$scope.moreform.thgraph,
                SubmittedBy=document.getElementById("useridside").innerHTML,
                CreationDate= new Date();

              //  id = document.getElementById("useridside").innerHTML;




      //Test to ensure that the user has entered both a make and model
      if (TotalAmountOfAllClouds !== "" && StationNumber !== "") {

                var query = "UPDATE moreformTable SET date=?,  StationName=?,  StationNumber=?,  time=?,  UnitofWindSpeed=?, Indoromissionofprecipitation=?, Typeofstationpresentpastweather=?,HeightOfLowestCloud=? , DurationOfPeriodOfPrecipitation=?, Standardisobaricsurface=?,  PastWeather=?,  GrassMininumtemperature=?,CharacterandIntensityofPrecipitation=?, BeginningorEndofPrecipitation=?,"+
                "Indicatoroftypeofintrumentation=?, DurationofSunshine=?,  SignofPressureChange=?, SupplementaryInformation=?,VapourPressure=?,  thgraph=?, SubmittedBy=?,CreationDate =? WHERE id=?";

      mydb.transaction(function (t) {
        //alert(date+time)
        t.executeSql(query, [date,  StationName,  StationNumber,  time,  UnitofWindSpeed, Indoromissionofprecipitation, Typeofstationpresentpastweather,HeightOfLowestCloud , DurationOfPeriodOfPrecipitation, Standardisobaricsurface,  PastWeather,  GrassMininumtemperature,CharacterandIntensityofPrecipitation, BeginningorEndofPrecipitation,
        Indicatoroftypeofintrumentation, DurationofSunshine,  SignofPressureChange, SupplementaryInformation,VapourPressure,  thgraph, SubmittedBy,CreationDate, id]);


          alert("The updates have been successfully made")


          });
      } else {
          alert("You must enter a StationNumber and TotalAmountOfAllClouds!");
      }
  } else {
      alert("db not found, your browser does not support web sql!");
  }


document.getElementById("myModal").style.display = "none";
}





 $scope.addObservationOffline=function() {
    //check to ensure the mydb object has been created

    if (mydb) {

        var  date=$scope.convertDate($scope.obv.date),
        StationName=document.getElementById("station_observationslipform").value,
        StationNumber= document.getElementById("stationNo_observationslipform").value,
          time=$scope.obv.time_observationslipform,
          TotalAmountOfAllClouds=$scope.obv.totalamountofallclouds_observationslipform,
          TotalAmountOfLowClouds=$scope.obv.totalamountoflowclouds_observationslipform,
           TypeOfLowClouds=$scope.obv.TypeOfLowClouds1_observationslipform,
           TypeOfLowClouds2=$scope.obv.TypeOfLowClouds2_observationslipform,
           TypeOfLowClouds3=$scope.obv.TypeOfLowClouds3_observationslipform,
          OktasOfLowClouds=$scope.obv.OktasOfLowClouds1_observationslipform,
          OktasOfLowClouds2=$scope.obv.OktasOfLowClouds2_observationslipform,
          OktasOfLowClouds3=$scope.obv.OktasOfLowClouds3_observationslipform,
           HeightOfLowClouds=$scope.obv.HeightLowClouds1_observationslipform,
           HeightOfLowClouds2=$scope.obv.HeightLowClouds2_observationslipform,
           HeightOfLowClouds3=$scope.obv.HeightLowClouds3_observationslipform,
          CLCODEOfLowClouds=$scope.obv.CLCODEOfLowClouds1_observationslipform,
          CLCODEOfLowClouds2=$scope.obv.CLCODEOfLowClouds2_observationslipform,
          CLCODEOfLowClouds3=$scope.obv.CLCODEOfLowClouds3_observationslipform,
           TypeOfMediumClouds=$scope.obv.TypeOfMediumClouds1_observationslipform,
           TypeOfMediumClouds2=$scope.obv.TypeOfMediumClouds2_observationslipform,
           TypeOfMediumClouds3=$scope.obv.TypeOfMediumClouds3_observationslipform,
          OktasOfMediumClouds=$scope.obv.OktasOfMediumClouds1_observationslipform,
          OktasOfMediumClouds2=$scope.obv.OktasOfMediumClouds2_observationslipform,
          OktasOfMediumClouds3=$scope.obv.OktasOfMediumClouds3_observationslipform,
          HeightOfMediumClouds=$scope.obv.HeightOfMediumClouds1_observationslipform,
          HeightOfMediumClouds2=$scope.obv.HeightOfMediumClouds2_observationslipform,
          HeightOfMediumClouds3=$scope.obv.HeightOfMediumClouds3_observationslipform,
          CLCODEOfMediumClouds=$scope.obv.CLCODEOfMediumClouds1_observationslipform,
          CLCODEOfMediumClouds2=$scope.obv.CLCODEOfMediumClouds2_observationslipform,
          CLCODEOfMediumClouds3=$scope.obv.CLCODEOfMediumClouds3_observationslipform,
          TypeOfHighClouds=$scope.obv.TypeOfHighClouds1_observationslipform,
          TypeOfHighClouds2=$scope.obv.TypeOfHighClouds2_observationslipform,
          TypeOfHighClouds3=$scope.obv.TypeOfHighClouds3_observationslipform,
            OktasOfHighClouds=$scope.obv.OktasOfHighClouds1_observationslipform,
            OktasOfHighClouds2=$scope.obv.OktasOfHighClouds2_observationslipform,
            OktasOfHighClouds3=$scope.obv.OktasOfHighClouds3_observationslipform,
          HeightOfHighClouds=$scope.obv.HeightOfHighClouds1_observationslipform,
          HeightOfHighClouds2=$scope.obv.HeightOfHighClouds2_observationslipform,
          HeightOfHighClouds3=$scope.obv.HeightOfHighClouds3_observationslipform,
          CLCODEOfHighClouds=$scope.obv.CLCODEOfHighClouds1_observationslipform,
          CLCODEOfHighClouds2=$scope.obv.CLCODEOfHighClouds2_observationslipform,
          CLCODEOfHighClouds3=$scope.obv.CLCODEOfHighClouds3_observationslipform,
           CloudSearchLightReading=$scope.obv.cloudsearchlight_observationslipform,
           Rainfall=$scope.obv.rainfall_observationslipform,
           Dry_Bulb=$scope.obv.drybulb_observationslipform,
            Wet_Bulb=$scope.obv.wetbulb_observationslipform,
             Max_Read=$scope.obv.maxRead_observationslipform,
              Max_Reset=$scope.obv.maxReset_observationslipform,
              Min_Read=$scope.obv.minRead_observationslipform,
              Min_Reset=$scope.obv.minReset_observationslipform,
              Piche_Read=$scope.obv.picheRead_observationslipform,
              Piche_Reset=$scope.obv.picheReset_observationslipform,
              TimeMarksThermo=$scope.obv.timemarksThermo_observationslipform,
              TimeMarksHygro=$scope.obv.timemarksHygro_observationslipform,
              TimeMarksRainRec=$scope.obv.timemarksRainRec_observationslipform ,
               Present_Weather=$scope.obv.presentweather_observationslipform,
               Visibility=$scope.obv.visibility_observationslipform,
              Wind_Direction=$scope.obv.winddirection_observationslipform,
              Wind_Speed=$scope.obv.windspeed_observationslipform ,
              Gusting=$scope.obv.gusting_observationslipform,
              AttdThermo=$scope.obv.attdThermo_observationslipform,
              PrAsRead=$scope.obv.prAsRead_observationslipform,
              Correction=$scope.obv.correction_observationslipform,
              clp=$scope.obv.CLP_observationslipform,
              MSLPr=$scope.obv.MSLPR_observationslipform,
              TimeMarksBarograph=$scope.obv.timeMarksBarograph_observationslipform,
              TimeMarksAnemograph=$scope.obv.timeMarksAnemograph_observationslipform,
              OtherTMarks=$scope.obv.otherTMarks_observationslipform,
              Remarks=$scope.obv.remarks_observationslipform,
              sunduration=$scope.obv.sunshineduration,
              windrun=$scope.obv.windrun,
              specitime=$scope.obv.specitime,
              SubmittedBy=document.getElementById("useridside").innerHTML, CreationDate = new Date();




        //Test to ensure that the user has entered both a make and model
        if (TotalAmountOfAllClouds !== "" ) {
          var query = "INSERT INTO obseravation_details__table (Date,  StationName,  StationNumber,  TIME,  TotalAmountOfAllClouds, TotalAmountOfLowClouds, TypeOfLowClouds, TypeOfLowClouds2, TypeOfLowClouds3, OktasOfLowClouds, OktasOfLowClouds2, OktasOfLowClouds3, HeightOfLowClouds, HeightOfLowClouds2, HeightOfLowClouds3, CLCODEOfLowClouds, CLCODEOfLowClouds2, CLCODEOfLowClouds3, TypeOfMediumClouds,TypeOfMediumClouds2,"+
          "TypeOfMediumClouds3, OktasOfMediumClouds,OktasOfMediumClouds2,OktasOfMediumClouds3, HeightOfMediumClouds, HeightOfMediumClouds2,HeightOfMediumClouds3,CLCODEOfMediumClouds,CLCODEOfMediumClouds2,CLCODEOfMediumClouds3,TypeOfHighClouds,TypeOfHighClouds2,TypeOfHighClouds3, OktasOfHighClouds, OktasOfHighClouds2,OktasOfHighClouds3,HeightOfHighClouds,HeightOfHighClouds2,HeightOfHighClouds3, CLCODEOfHighClouds, CLCODEOfHighClouds2, CLCODEOfHighClouds3, CloudSearchLightReading, Rainfall,Dry_Bulb,"+ "Wet_Bulb,Max_Read,Max_Reset,Min_Read,Min_Reset,Piche_Read,Piche_Reset,TimeMarksThermo,TimeMarksHygro,TimeMarksRainRec,Present_Weather,Visibility,Wind_Direction,Wind_Speed ,Gusting,AttdThermo,PrAsRead,Correction,CLP,MSLPr,TimeMarksBarograph,TimeMarksAnemograph,OtherTMarks,Remarks,windrun,sunduration,specitime,SubmittedBy,CreationDate) VALUES "+
          "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        mydb.transaction(function (t) {

          t.executeSql(query, [date,  StationName,  StationNumber,  time,  TotalAmountOfAllClouds, TotalAmountOfLowClouds, TypeOfLowClouds,TypeOfLowClouds2,TypeOfLowClouds3,
                          OktasOfLowClouds,OktasOfLowClouds2,OktasOfLowClouds3, HeightOfLowClouds,HeightOfLowClouds2,HeightOfLowClouds3, CLCODEOfLowClouds,  CLCODEOfLowClouds2, CLCODEOfLowClouds3,TypeOfMediumClouds,TypeOfMediumClouds2,TypeOfMediumClouds3, OktasOfMediumClouds,  OktasOfMediumClouds2,  OktasOfMediumClouds3, HeightOfMediumClouds, HeightOfMediumClouds2,  HeightOfMediumClouds3,  CLCODEOfMediumClouds,CLCODEOfMediumClouds2,CLCODEOfMediumClouds3,
                           TypeOfHighClouds, TypeOfHighClouds2,TypeOfHighClouds3,OktasOfHighClouds, OktasOfHighClouds2,OktasOfHighClouds3,HeightOfHighClouds,HeightOfHighClouds2,HeightOfHighClouds3, CLCODEOfHighClouds,  CLCODEOfHighClouds2,  CLCODEOfHighClouds3, CloudSearchLightReading, Rainfall,Dry_Bulb, Wet_Bulb,
                           Max_Read, Max_Reset,Min_Read,  Min_Reset,Piche_Read,Piche_Reset,TimeMarksThermo,TimeMarksHygro,TimeMarksRainRec ,
                           Present_Weather,Visibility,Wind_Direction,Wind_Speed ,Gusting,AttdThermo,PrAsRead,Correction,clp,MSLPr,TimeMarksBarograph,TimeMarksAnemograph,OtherTMarks,Remarks,windrun,sunduration,specitime,SubmittedBy, CreationDate]);

                $scope.displayData();
                alert("your data has been successfully saved offline to view it click on pending uploads menu")
            });
        } else {
            alert("You must enter a StationNumber and TotalAmountOfAllClouds!");
        }
    } else {
        alert("db not found, your browser does not support web sql!");
    }
}


 $scope.addmoreformOffline=function() {
    //check to ensure the mydb object has been created

    if (mydb) {

        var  date=$scope.convertDate($scope.moreform.date),
        StationName=document.getElementById("station_moreform").value,
        StationNumber= document.getElementById("stationNo_moreform").value,
          time=$scope.moreform.time_observationslipform,
           UnitofWindSpeed=$scope.moreform.UnitofWindSpeed,
            Indoromissionofprecipitation=$scope.moreform.Indoromissionofprecipitation,
            Typeofstationpresentpastweather=$scope.moreform.Typeofstationpresentpastweather,
            HeightOfLowestCloud=$scope.moreform.HeightOfLowestCloud,
            DurationOfPeriodOfPrecipitation=$scope.moreform.DurationOfPeriodOfPrecipitation,
            Standardisobaricsurface=$scope.moreform.Standardisobaricsurface,
            PastWeather=$scope.moreform.PastWeather,
            GrassMininumtemperature=$scope.moreform.GrassMininumtemperature,
            CharacterandIntensityofPrecipitation=$scope.moreform.CharacterandIntensityofPrecipitation ,
            BeginningorEndofPrecipitation=$scope.moreform.BeginningorEndofPrecipitation,
            Indicatoroftypeofintrumentation=$scope.moreform.Indicatoroftypeofintrumentation,
            DurationofSunshine=$scope.moreform.DurationofSunshine,
            SignofPressureChange=$scope.moreform.SignofPressureChange ,
            SupplementaryInformation=$scope.moreform.SupplementaryInformation,
            VapourPressure=$scope.moreform.VapourPressure,
            thgraph=$scope.moreform.thgraph,
            SubmittedBy=document.getElementById("useridside").innerHTML,
            CreationDate= new Date();;




        //Test to ensure that the user has entered both a make and model
        if (date !== "" && StationNumber !== "") {
          var query = "INSERT INTO moreformTable (date,  StationName,  StationNumber,  time,  UnitofWindSpeed, Indoromissionofprecipitation, Typeofstationpresentpastweather,HeightOfLowestCloud , DurationOfPeriodOfPrecipitation, Standardisobaricsurface,  PastWeather,  GrassMininumtemperature,CharacterandIntensityofPrecipitation, BeginningorEndofPrecipitation,"+
          "Indicatoroftypeofintrumentation, DurationofSunshine,  SignofPressureChange, SupplementaryInformation,VapourPressure,  thgraph, SubmittedBy,CreationDate) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        mydb.transaction(function (t) {
          t.executeSql(query, [date,  StationName,  StationNumber,  time,  UnitofWindSpeed, Indoromissionofprecipitation, Typeofstationpresentpastweather,HeightOfLowestCloud ,DurationOfPeriodOfPrecipitation, Standardisobaricsurface,  PastWeather,  GrassMininumtemperature,CharacterandIntensityofPrecipitation, BeginningorEndofPrecipitation, Indicatoroftypeofintrumentation, DurationofSunshine,  SignofPressureChange, SupplementaryInformation,VapourPressure,  thgraph, SubmittedBy,CreationDate],
                                   function(tx, rs) { console.log("inserted more") },
                                   function(tx, err) { console.log("Error in insertion of more occurred: " +JSON.stringify(err)) });

                            alert("your data has been successfully saved offline to view it click on pending uploads menu")
          $scope.displayData0();

            });
        } else {
            alert("You must enter a StationNumber and TotalAmountOfAllClouds!");
        }
    } else {
        alert("db not found, your browser does not support web sql!");
    }
}
$scope.deleteFromOffline=  function(id) {
//alert()
    //check to ensure the mydb object has been created
    if (mydb) {
        //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
        mydb.transaction(function (t) {
            t.executeSql("DELETE FROM obseravation_details__table WHERE id=?", [id], $scope.displayData);
alert("deleted");
        });
    } else {
        alert("db not found, your browser does not support web sql!");
    }
}

$scope.displayData();
})

app.controller('homeCtrl', function($scope, $http, LoginService){
$scope.loginUsingOnline=function(){

  $scope.loginData = {
    'userName' : $scope.username,
    'password' : $scope.password
  };

  if($scope.loginData.userName !=null && $scope.loginData.password !=null){
  LoginService.loginUser($scope.loginData).success(function(data) {
    if (mydb) {

        //alert(LoginService.getUserStation() + LoginService.getUserStationNo());
      //Insert the user entered details into the cars table, note the use of the ? placeholder, these will replaced by the data passed in as an array as the second parameter
            mydb.transaction(function (t) {
              t.executeSql("SELECT * FROM user_Details_table WHERE username = ?", [$scope.loginData.userName],
              function(transaction, results){
                var len = results.rows.length, i;
                if (len>0) {
                  alert("online Logging in ..." );
                  t.executeSql("UPDATE  user_Details_table SET password=? WHERE username = ?", [$scope.loginData.userName,$scope.loginData.password],
                  console.log("inserted UPDATED")
                );
                  location.href = "newObservationFormSlip.html";
                }
                else{
                  t.executeSql("INSERT INTO user_Details_table (userId, username, password, stationName, stationNumber) VALUES (?, ?, ?, ?, ?)", [ LoginService.getUserId(),$scope.loginData.userName,$scope.loginData.password,LoginService.getUserStation(), LoginService.getUserStationNo()],
                    console.log("inserted successfully")
                );
                }

              });


            });

              location.href = "newObservationFormSlip.html";

    } else {
        alert("db not found, your browser does not support web sql!");
    }


  }).error(function(data) {

        alert("fake details entered")
  });
}else{
    alert("Password or email is missing");
}
}

  $scope.loginUsingOffline = function() {

    $scope.loginData = {
      'userName' : $scope.username,
      'password' : $scope.password
    };


        if($scope.loginData.userName !=null && $scope.loginData.password !=null) {
          if (mydb) {
              mydb.transaction(function (t) {
                  t.executeSql("SELECT * FROM user_Details_table WHERE username = ? AND password = ?", [$scope.loginData.userName, $scope.loginData.password],
                  function(transaction, results){
                    var len = results.rows.length, i;
                    if (len>0) {
                      alert("offline Logging in ..." + len);
                      location.href = "newObservationFormSlip.html";
                    }
                    else{
                      alert("Credentials used seem Incorrect Login while online to comfirm!");
                    }

                  });
              });


          } else {
                  alert("no db supported")
            }


  }
    else {
    alert("Password or email is missing");

    }


}




  $scope.doesConnectionExist =function() {
        var xhr = new XMLHttpRequest();
        var file = "https://www.google.com/";
        var randomNum = Math.round(Math.random() * 10000);

        xhr.open('HEAD', file + "?rand=" + randomNum, true);
        xhr.send();

        xhr.addEventListener("readystatechange", processRequest, false);

        function processRequest(e) {
          if (xhr.readyState == 4) {
            if (xhr.status >= 200 && xhr.status < 304) {
              //alert("connection exists!");
              $scope.loginUsingOnline();
            } else {
              //alert("connection doesn't exist!");
                $scope.loginUsingOffline();
            }
          }
        }
    }

var c= null;

  $scope.usernamefromdb ="";
    $scope.outputUsers = function() {

          //  $scope.createDatabase();
          //check to ensure the mydb object has been created
          if (mydb) {
          //  var username = document.getElementById("username").value;
            //var password = document.getElementById("password").value;

              //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
              mydb.transaction(function (t) {
                  t.executeSql("SELECT * FROM user_Details_table", [],
                  function(transaction, results){
                    var len = results.rows.length, i;
                    if (len>0) {

                     $scope.usernamefromdb = results.rows.item(0).username;
                     document.getElementById("username_side").innerHTML =results.rows.item(0).username;
                     document.getElementById("username_main").innerHTML =results.rows.item(0).username;
                     document.getElementById("stationname_main").innerHTML =results.rows.item(0).stationName;
                     document.getElementById("stationnumber_main").innerHTML =results.rows.item(0).stationNumber;

                    }
                    else{

                    }

                  });
              });
              return c;

          } else {
              return c;
            }
      }

$scope.addcontent = function(){

      //check to ensure the mydb object has been created

}

  $scope.createDatabase = function(){



        if (window.openDatabase) {

            //create the cars table using SQL for the database using a transaction
            mydb.transaction(function (t) {
          //      t.executeSql("CREATE TABLE IF NOT EXISTS cars (id INTEGER PRIMARY KEY ASC, make TEXT, model TEXT)");
                t.executeSql("CREATE TABLE IF NOT EXISTS user_Details_table(userId, username, password, stationName,stationNumber)");
            });

            //alert("database created");

        } else {
            alert("WebSQL is not supported by your browser!");
        }


  }






  })
    /*document.getElementById("signin").onclick = function () {



//    alert("jojo");
      alert("cnsjn");
      // outputUsers($scope.username,$scope.password);

      //  location.href = "newObservationFormSlip.html";


    };*/
