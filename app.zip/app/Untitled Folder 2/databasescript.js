  var mydb ="";
  var usernamestored =""
var app = angular.module('myApp', []);

app.service('LoginService', function ($q, $http) {
      var user=""; var userStationNo=""; var userStation="";
  return {
    loginUser: function (loginData) {
        var deferred = $q.defer(),
        promise = deferred.promise;


        $http({
          url: 'http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/loginMobile.php',
          method: "POST",
          data: loginData,
          headers: {'Content-Type': 'application/x-www-form-urlencoded'}
        }) .then(function (response) {
          if (response.data.error.code === "000") {
            //console.log("User login successful: " + JSON.stringify(response.data));
            deferred.resolve("Welcome");
            user = response.data.userData.name;
            userStationNo=response.data.userData.stationNumber;;
             userStation=response.data.userData.stationName;;

          } else {
            //console.log("User login failed: " + JSON.stringify(response.data.error));
            deferred.reject("Wrong credential");
          }
        }, function (error) {
          //console.log("Server Error on login: " + JSON.stringify(error));
          deferred.reject("Wrong credential");
        });

        promise.success = function (fn) {
          promise.then(fn);
          return promise;
        };
        promise.error = function (fn) {
          promise.then(null, fn);
          return promise;
        };
        return promise;
      }, getUser: function(){
            return user;
      }, getUserStation: function(){
            return userStation;
      }
      , getUserStationNo: function(){
            return userStationNo;
      }
}
})
app.controller("HomeTabCtrl",function($scope,$compile,$http){
if (window.openDatabase) {
    //Create the database the parameters are 1. the database name 2.version number 3. a description 4. the size of the database (in bytes) 1024 x 1024 = 1MB
    var mydb = openDatabase("mydb", "0.1", "A Database of weather Record I Like", 1024 * 1024);
    //create the cars table using SQL for the database using a transaction
    mydb.transaction(function (t) {
    t.executeSql(" CREATE TABLE IF NOT EXISTS observation_Table(id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,Date,  StationName,  StationNumber,  TIME,  TotalAmountOfAllClouds, TotalAmountOfLowClouds, TypeOfLowClouds, TypeOfLowClouds2, TypeOfLowClouds3, OktasOfLowClouds, OktasOfLowClouds2, OktasOfLowClouds3, HeightOfLowClouds, HeightOfLowClouds2, HeightOfLowClouds3, CLCODEOfLowClouds, CLCODEOfLowClouds2, CLCODEOfLowClouds3, TypeOfMediumClouds,TypeOfMediumClouds2,"+
    "TypeOfMediumClouds3, OktasOfMediumClouds,OktasOfMediumClouds2,OktasOfMediumClouds3, HeightOfMediumClouds, HeightOfMediumClouds2,HeightOfMediumClouds3,CLCODEOfMediumClouds,CLCODEOfMediumClouds2,CLCODEOfMediumClouds3,TypeOfHighClouds,TypeOfHighClouds2,TypeOfHighClouds3, OktasOfHighClouds, OktasOfHighClouds2,OktasOfHighClouds3,HeightOfHighClouds,HeightOfHighClouds2,HeightOfHighClouds3, CLCODEOfHighClouds, CLCODEOfHighClouds2, CLCODEOfHighClouds3, CloudSearchLightReading, Rainfall,Dry_Bulb,"+ "Wet_Bulb, Max_Read, Max_Reset,Min_Read,  Min_Reset,Piche_Read,Piche_Reset,TimeMarksThermo,TimeMarksHygro,TimeMarksRainRec , Present_Weather,Visibility,Wind_Direction,Wind_Speed ,Gusting,AttdThermo,PrAsRead,Correction,CLP,MSLPr,TimeMarksBarograph,TimeMarksAnemograph,OtherTMarks,Remarks,SubmittedBy,CreationDate)");
    });

} else
    alert("WebSQL is not supported by your browser!");
$scope.convertDate=function(date) {
     var yyyy = date.getFullYear().toString();
     var mm = (date.getMonth()+1).toString();
     var dd  = date.getDate().toString();

     var mmChars = mm.split('');
     var ddChars = dd.split('');

     return yyyy + '-' + (mmChars[1]?mm:"0"+mmChars[0]) + '-' + (ddChars[1]?dd:"0"+ddChars[0]);
    }
    $scope.convertTime=function(date) {
     var hh = date.getHours().toString();
     var mm  = date.getMinutes().toString();

     return (hh<10? "0"+hh : hh)+ ':' +(mm<10? "0"+mm : mm) ;
    }
$scope.obv={};
//function to output the list of cars in the database
$scope.submitObservation=function(){

$scope.addObservationOffline();

  $scope.observationData={
    "date":$scope.convertDate($scope.obv.date),
    "StationName":$scope.obv.station_observationslipform,
    "StationNumber":$scope.obv.stationNo_observationslipform,
     "time":$scope.convertTime($scope.obv.time_observationslipform),
     "TotalAmountOfAllClouds":$scope.obv.totalamountofallclouds_observationslipform,
     "TotalAmountOfLowClouds":$scope.obv.totalamountoflowclouds_observationslipform,
      "TypeOfLowClouds":$scope.obv.TypeOfLowClouds1_observationslipform,
      "TypeOfLowClouds2":$scope.obv.TypeOfLowClouds2_observationslipform,
      "TypeOfLowClouds3":$scope.obv.TypeOfLowClouds3_observationslipform,
     "OktasOfLowClouds":$scope.obv.OktasOfLowClouds1_observationslipform,
     "OktasOfLowClouds2":$scope.obv.OktasOfLowClouds2_observationslipform,
     "OktasOfLowClouds3":$scope.obv.OktasOfLowClouds3_observationslipform,
      "HeightOfLowClouds":$scope.obv.HeightLowClouds1_observationslipform,
      "HeightOfLowClouds2":$scope.obv.HeightLowClouds2_observationslipform,
      "HeightOfLowClouds3":$scope.obv.HeightLowClouds3_observationslipform,
     "CLCODEOfLowClouds":$scope.obv.CLCODEOfLowClouds1_observationslipform,
     "CLCODEOfLowClouds2":$scope.obv.CLCODEOfLowClouds2_observationslipform,
     "CLCODEOfLowClouds3":$scope.obv.CLCODEOfLowClouds3_observationslipform,
      "TypeOfMediumClouds":$scope.obv.TypeOfMediumClouds1_observationslipform,
      "TypeOfMediumClouds2":$scope.obv.TypeOfMediumClouds2_observationslipform,
      "TypeOfMediumClouds3":$scope.obv.TypeOfMediumClouds3_observationslipform,
     "OktasOfMediumClouds":$scope.obv.OktasOfMediumClouds1_observationslipform,
     "OktasOfMediumClouds2":$scope.obv.OktasOfMediumClouds2_observationslipform,
     "OktasOfMediumClouds3":$scope.obv.OktasOfMediumClouds3_observationslipform,
     "HeightOfMediumClouds":$scope.obv.HeightOfMediumClouds1_observationslipform,
     "HeightOfMediumClouds2":$scope.obv.HeightOfMediumClouds2_observationslipform,
     "HeightOfMediumClouds3":$scope.obv.HeightOfMediumClouds3_observationslipform,
     "CLCODEOfMediumClouds":$scope.obv.CLCODEOfMediumClouds1_observationslipform,
     "CLCODEOfMediumClouds2":$scope.obv.CLCODEOfMediumClouds2_observationslipform,
     "CLCODEOfMediumClouds3":$scope.obv.CLCODEOfMediumClouds3_observationslipform,
     "TypeOfHighClouds":$scope.obv.TypeOfHighClouds1_observationslipform,
     "TypeOfHighClouds2":$scope.obv.TypeOfHighClouds2_observationslipform,
     "TypeOfHighClouds3":$scope.obv.TypeOfHighClouds3_observationslipform,
       "OktasOfHighClouds":$scope.obv.OktasOfHighClouds1_observationslipform,
       "OktasOfHighClouds2":$scope.obv.OktasOfHighClouds2_observationslipform,
       "OktasOfHighClouds3":$scope.obv.OktasOfHighClouds3_observationslipform,
     "HeightOfHighClouds":$scope.obv.HeightOfHighClouds1_observationslipform,
     "HeightOfHighClouds2":$scope.obv.HeightOfHighClouds2_observationslipform,
     "HeightOfHighClouds3":$scope.obv.HeightOfHighClouds3_observationslipform,
      "CLCODEOfHighClouds":$scope.obv.CLCODEOfHighClouds1_observationslipform,
      "CLCODEOfHighClouds2":$scope.obv.CLCODEOfHighClouds2_observationslipform,
      "CLCODEOfHighClouds3":$scope.obv.CLCODEOfHighClouds3_observationslipform,
      "CloudSearchLightReading":$scope.obv.cloudsearchlight_observationslipform,
      "Rainfall":$scope.obv.rainfall_observationslipform,
      "Dry_Bulb":$scope.obv.drybulb_observationslipform,
       "Wet_Bulb":$scope.obv.wetbulb_observationslipform,
        "Max_Read":$scope.obv.maxRead_observationslipform,
         "Max_Reset":$scope.obv.maxReset_observationslipform,
         "Min_Read":$scope.obv.minRead_observationslipform,
         "Min_Reset":$scope.obv.minReset_observationslipform,
         "Piche_Read":$scope.obv.picheRead_observationslipform,
         "Piche_Reset":$scope.obv.picheReset_observationslipform,
         "TimeMarksThermo":$scope.obv.timemarksThermo_observationslipform,
         "TimeMarksHygro":$scope.obv.timemarksHygro_observationslipform,
         "TimeMarksRainRec":$scope.obv.timemarksRainRec_observationslipform ,
          "Present_Weather":$scope.obv.presentweather_observationslipform,
          "Visibility":$scope.obv.visibility_observationslipform,
         "Wind_Direction":$scope.obv.winddirection_observationslipform,
         "Wind_Speed": $scope.obv.windspeed_observationslipform,
         "Gusting":$scope.obv.gusting_observationslipform,
         "AttdThermo":$scope.obv.attdThermo_observationslipform,
         "PrAsRead":$scope.obv.prAsRead_observationslipform,
         "Correction":$scope.obv.correction_observationslipform,
         "clp":$scope.obv.CLP_observationslipform,
         "MSLPr":$scope.obv.MSLPR_observationslipform,
         "TimeMarksBarograph":$scope.obv.timeMarksBarograph_observationslipform,
         "TimeMarksAnemograph":$scope.obv.timeMarksAnemograph_observationslipform,
         "OtherTMarks":$scope.obv.otherTMarks_observationslipform,
         "Remarks":$scope.obv.remarks_observationslipform,
         "SubmittedBy":"1221" ,
         "DeviceType":"desktop"
  };



    $http({
   method : "POST",
   url : "http://www.wimea.mak.ac.ug/wimeamobile/weatherMobile/observationformScript.php",
   data: $scope.observationData,
  headers: {'Content-Type': 'application/x-www-form-urlencoded'}
  }).then(function mySuccess(response) {
  // $scope.myWelcome = response.data;
  alert("Success"+response.data.message);
  }, function myError(response) {
   //$scope.myWelcome = response.statusText;
  alert("Error"+JSON.stringify(response) );
  });





}
$scope.loadobvpendingview = function(){

  $scope.observationpart1 = true;
  $scope.observationpart2 = false;
  $scope.observationpart3 = false;
  $scope.observationpart4 = false;


}


$scope.loadobvViews = function(){
  $scope.obv.station_observationslipform =$scope.getUserDetails()[1];
  $scope.obv.stationNo_observationslipform = $scope.getUserDetails()[2];

  $scope.observationpart1 = true;
  $scope.observationpart2 = false;
  $scope.observationpart3 = false;
  $scope.observationpart4 = false;


}

$scope.openobvView = function(viewname){
  if(viewname == "observationpart1"){
    $scope.observationpart1 = true;
    $scope.observationpart2 = false;
    $scope.observationpart3 = false;
    $scope.observationpart4 = false;
  }
  else if(viewname == "observationpart2"){
    $scope.observationpart1 = false;
    $scope.observationpart2 = true;
    $scope.observationpart3 = false;
    $scope.observationpart4 = false;
}
else if(viewname == "observationpart3"){
  $scope.observationpart1 = false;
  $scope.observationpart2 = false;
  $scope.observationpart3 = true;
  $scope.observationpart4 = false;

}
else if(viewname == "observationpart4"){
  $scope.observationpart1 = false;
  $scope.observationpart2 = false;
  $scope.observationpart3 = false;
  $scope.observationpart4 = true;

}
}

$scope.observationData = [];
var huh = false;
$scope.showNawe = function(){
  $.when($scope.openLine(function (users){
    $scope.observationData = users;
        $scope.openme(users);
      ////alert($scope.observationData+"jozhu<ddd");

    })).then(//alert($scope.observationData +"failed<ddd")
  );






}
$scope.openme = function(user){
  $scope.observationData = user;
  ////alert($scope.observationData +"testing if data comes");
  var innerContent =        ' <div class="table" id>' +
' <div class="row header blue">'+
  ' <div class="cell">'+
  '  Record type'+
  ' </div>'+
  ' <div class="cell">'+
    ' Date and Time'+
  ' </div>'+
  ' <div class="cell">'+
  '   Edit'+
  ' </div>'+
  ' <div class="cell">'+
  '   Upload'+
  ' </div>'+
' </div>';

for(i = 0; i<$scope.observationData.length; i++ ){
  ////alert($scope.observationData[i].name);
  x = "sssssss";
  innerContent += ' <div class="row" >'+
    ' <div class="cell">'+
      'Observation form'+
    ' </div>'+
    '<div class="cell">'+$scope.observationData[i].name+' </div>'+
    ' <div class="cell">'+
      ' <button class="btn btn-primary button-size" ng-click = "openModal(\''+$scope.observationData[i].id+'\')">edit</button>'+
    ' </div>'+
    ' <div class="cell">'+
      ' <button class="btn btn-success button-size">Upload</button>'+
     ' </div>'+
   ' </div>';
}

 innerContent +='</div>';

  document.getElementById("pendingUploads").innerHTML = innerContent;

  $compile(document.getElementById("pendingUploads"))($scope);



}

  $scope.selectObservation = function(data_id, callback){
    if (mydb) {
            var detailsselected = [];
        //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
        mydb.transaction(function (t) {
          var demo = [];
            t.executeSql("SELECT * FROM observation_Table where id=?", [data_id],   function(transaction, results) {
                //initialise the listitems variable
                  if(results.rows.length> 0){
                      var row = results.rows.item(0);
                    detailsselected[0] = row;
                      callback(detailsselected);

                  }

            });

        });

    } else {
        //alert("db not found, your browser does not support web sql!");

    }

  }

$scope.openModal = function(data_tracked){
  ////alert($scope.selectObservation(data_tracked)[0] + "shows now")
  $scope.selectObservation(data_tracked, function (users){
  //  $scope.observationData = users;
      //  $scope.openme(users);
        ////alert(users.length);


         $scope.obv.date = new Date(users[0].Date)
          $scope.obv.station_observationslipform = users[0].StationName
           $scope.obv.stationNo_observationslipform = users[0].StationNumber
            $scope.obv.time_observationslipform = new Date(2017, 01, 01, (users[0].TIME).split(":")[0], (users[0].TIME).split(":")[1], 00, 00)//new Date(users[0].TIME)
            $scope.obv.totalamountofallclouds_observationslipform = users[0].TotalAmountOfAllClouds
            $scope.obv.totalamountoflowclouds_observationslipform = users[0].TotalAmountOfLowClouds
            $scope.obv.TypeOfLowClouds1_observationslipform = users[0].TypeOfLowClouds
            $scope.obv.TypeOfLowClouds2_observationslipform = users[0].TypeOfLowClouds2
            $scope.obv.TypeOfLowClouds3_observationslipform = users[0].TypeOfLowClouds3
            $scope.obv.OktasOfLowClouds1_observationslipform = users[0].OktasOfLowClouds
            $scope.obv.OktasOfLowClouds2_observationslipform = users[0].OktasOfLowClouds2
            $scope.obv.OktasOfLowClouds3_observationslipform = users[0].OktasOfLowClouds3
            $scope.obv.HeightLowClouds1_observationslipform= users[0].HeightOfLowClouds
            $scope.obv.HeightLowClouds2_observationslipform= users[0].HeightOfLowClouds2
            $scope.obv.HeightLowClouds3_observationslipform= users[0].HeightOfLowClouds3
            $scope.obv.CLCODEOfLowClouds1_observationslipform = users[0].CLCODEOfLowClouds
            $scope.obv.CLCODEOfLowClouds2_observationslipform = users[0].CLCODEOfLowClouds2
            $scope.obv.CLCODEOfLowClouds3_observationslipform = users[0].CLCODEOfLowClouds3
            $scope.obv.TypeOfMediumClouds1_observationslipform = users[0].TypeOfMediumClouds
            $scope.obv.TypeOfMediumClouds2_observationslipform = users[0].TypeOfMediumClouds2
            $scope.obv.TypeOfMediumClouds3_observationslipform = users[0].TypeOfMediumClouds3
            $scope.obv.OktasOfMediumClouds1_observationslipform = users[0].OktasOfMediumClouds
            $scope.obv.OktasOfMediumClouds2_observationslipform = users[0].OktasOfMediumClouds2
            $scope.obv.OktasOfMediumClouds3_observationslipform = users[0].OktasOfMediumClouds3
            $scope.obv.HeightOfMediumClouds1_observationslipform = users[0].HeightOfMediumClouds
            $scope.obv.HeightOfMediumClouds2_observationslipform = users[0].HeightOfMediumClouds2
            $scope.obv.HeightOfMediumClouds3_observationslipform = users[0].HeightOfMediumClouds3
            $scope.obv.CLCODEOfMediumClouds1_observationslipform = users[0].CLCODEOfMediumClouds
            $scope.obv.CLCODEOfMediumClouds2_observationslipform = users[0].CLCODEOfMediumClouds2
            $scope.obv.CLCODEOfMediumClouds3_observationslipform = users[0].CLCODEOfMediumClouds3
            $scope.obv.TypeOfHighClouds1_observationslipform = users[0].TypeOfHighClouds
            $scope.obv.TypeOfHighClouds2_observationslipform = users[0].TypeOfHighClouds2
            $scope.obv.TypeOfHighClouds3_observationslipform = users[0].TypeOfHighClouds3
            $scope.obv.OktasOfHighClouds1_observationslipform = users[0].OktasOfHighClouds
            $scope.obv.OktasOfHighClouds2_observationslipform = users[0].OktasOfHighClouds2
            $scope.obv.OktasOfHighClouds3_observationslipform = users[0].OktasOfHighClouds3
            $scope.obv.HeightOfHighClouds1_observationslipform = users[0].HeightOfHighClouds
            $scope.obv.HeightOfHighClouds2_observationslipform = users[0].HeightOfHighClouds2
            $scope.obv.HeightOfHighClouds3_observationslipform = users[0].HeightOfHighClouds3
            $scope.obv.CLCODEOfHighClouds1_observationslipform = users[0].CLCODEOfHighClouds
            $scope.obv.CLCODEOfHighClouds2_observationslipform = users[0].CLCODEOfHighClouds2
            $scope.obv.CLCODEOfHighClouds3_observationslipform = users[0].CLCODEOfHighClouds3
            $scope.obv.cloudsearchlight_observationslipform = users[0].CloudSearchLightReading
            $scope.obv.rainfall_observationslipform = users[0].Rainfall
            $scope.obv.drybulb_observationslipform = users[0].Dry_Bulb
            $scope.obv.wetbulb_observationslipform = users[0].Wet_Bulb
            $scope.obv.maxRead_observationslipform = users[0].Max_Read
            $scope.obv.maxReset_observationslipform = users[0].Max_Reset
            $scope.obv.minRead_observationslipform = users[0].Min_Read
            $scope.obv.minReset_observationslipform = users[0].Min_Reset
            $scope.obv.picheRead_observationslipform = users[0].Piche_Read
          $scope.obv.picheReset_observationslipform = users[0].Piche_Reset
            $scope.obv.timemarksThermo_observationslipform = users[0].TimeMarksThermo
            $scope.obv.timemarksHygro_observationslipform = users[0].TimeMarksHygro
            $scope.obv.timemarksRainRec_observationslipform = users[0].TimeMarksRainRec
            $scope.obv.presentweather_observationslipform = users[0].Present_Weather
            $scope.obv.visibility_observationslipform = users[0].Visibility
            $scope.obv.winddirection_observationslipform = users[0].Wind_Direction
            $scope.obv.windspeed_observationslipform = users[0].Wind_Speed
            $scope.obv.gusting_observationslipform = users[0].Gusting
            $scope.obv.attdThermo_observationslipform = users[0].AttdThermo
            $scope.obv.prAsRead_observationslipform = users[0].PrAsRead
            $scope.obv.correction_observationslipform = users[0].Correction
            $scope.obv.CLP_observationslipform = users[0].CLP
            $scope.obv.MSLPR_observationslipform = users[0].MSLPr
            $scope.obv.timeMarksBarograph_observationslipform = users[0].TimeMarksBarograph
            $scope.obv.timeMarksAnemograph_observationslipform = users[0].TimeMarksAnemograph
            $scope.obv.otherTMarks_observationslipform = users[0].OtherTMarks
            $scope.obv.remarks_observationslipform = users[0].Remarks

            $scope.fillmodal(users[0].id);





        //alert( $scope.totalamountofallclouds_observationslipform + "nkwagala");
    })


  //$scope.totalamountofallclouds_observationslipform =   $scope.selectObservation(data_tracked)[0];

  //$scope.totalamountofallclouds_observationslipform = data_tracked;
  var modal = document.getElementById('myModal');

  // Get the button that opens the modal
  var btn = document.getElementById("edit");

  // Get the <span> element that closes the modal
  var span = document.getElementsByClassName("close")[0];

  // When the user clicks the button, open the modal

        modal.style.display = "block";


      span.onclick = function() {
          modal.style.display = "none";
      }

      // When the user clicks anywhere outside of the modal, close it
      window.onclick = function(event) {
          if (event.target == modal) {
              modal.style.display = "none";
          }
      }


      ////alert("click to update entries")


}

  $scope.fillmodal = function(record_id) {
    alert(record_id);
    var content_in_modal = "";

    content_in_modal += '<div class="row observation-form" ng-show="observationpart1" >'+
'<table class="table table-bordered">'+
' <thead><tr>'+
        ' <th colspan="12" class="head-center">Cloud entries</th>'+
        ' </tr>'+
' </thead>'+
  ' <tbody>'+
  '   <tr> '+
      ' <td colspan="6">'+
      '<div class="form-group">'+
              ' <div class="input-group col-xs-12">'+
                  ' <span class="input-group-addon">Total amount of all clouds</span>'+
                  ' <input type="text" name="totalamountofallclouds_observationslipform"  ng-model="obv.totalamountofallclouds_observationslipform"  class="form-control" required placeholder=" Enter total amount of all clouds"  value="sssssss">'+
              ' </div> '+
        '   </div> '+
      ' </td>'+
      ' <td colspan="6"> '+
      '   <div class="form-group"> '+
            ' <div class="input-group col-xs-12"> '+
              '   <span class="input-group-addon">Total amount of low clouds</span> '+
              '   <input type="text" name="totalamountoflowclouds_observationslipform" ng-model="obv.totalamountoflowclouds_observationslipform" class="form-control" required placeholder="Enter total amount of low clouds" > '+
          '   </div>'+
        '</div>'+
      '</td>'+
    '</tr>'+
    '<tr>'+
      '<td colspan="6">'+
        ' <div class="form-group col-xs-12">'+
          '   <div class="input-group"> '+
                ' <span class="input-group-addon">Select Date</span>'+
                ' <input type="date" name="date_observationslipform" ng-model="obv.date" required class="form-control" placeholder="Enter select date" > '+
              '   <input type="hidden" name="checkduplicateEntryOnAddObservationSlipFormData_hiddentextfield" ng-model="obv.checkduplicateEntryOnAddObservationSlipFormData_hiddentextfield"> '+

            ' </div>'+
        ' </div>'+
      ' </td> '+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12">'+
            ' <div class="input-group">'+
                '<span class="input-group-addon">TIME</span>'+
                ' <input type="time" name="time_observationslipform" ng-model="obv.time_observationslipform" required class="form-control" >'+
            '</div>'+
        ' </div>'+
      ' </td> '+
    ' </tr>'+
    ' <tr> '+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12"> '+
            ' <div class="input-group">'+
                ' <span class="input-group-addon">Station Name</span> '+
                ' <input type="text" name="station_observationslipform" ng-model="obv.station_observationslipform" required class="form-control" value="Makerere"  readonly class="form-control" > '+
            ' </div> '+
        ' </div> '+
      ' </td>'+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                ' <span class="input-group-addon"> Station Number</span> '+
                ' <input type="text" name="stationNo_observationslipform" ng-model="obv.stationNo_observationslipform" required class="form-control"  readonly class="form-control" value="400098" readonly="readonly" >'+
            '</div>'+
        '</div>'+
      '</td>'+
    '</tr>'+
    '<tr>'+
        '<th colspan="4" class="head-center">Low</th>'+
        '<th colspan="4" class="head-center">High</th>'+
        '<th colspan="4" class="head-center">Medium</th>'+
    '</tr>'+
    '<tr>'+
        '<th  colspan="1">type</th>'+
        '<th colspan="1">oktas</th>'+
        '<th colspan="1">height</th>'+
        '<th colspan="1">clcode</th>'+
        '<th  colspan="1">type</th>'+
        '<th colspan="1">oktas</th>'+
        '<th colspan="1">height</th>'+
        '<th colspan="1">clcode</th>'+
        '<th  colspan="1">type</th>'+
        '<th colspan="1">oktas</th>'+
        '<th colspan="1">height</th>'+
        '<th colspan="1">clcode</th>'+
    '</tr>'+
      '<tr>'+
          '<td colspan="1">'+
            '<select  name="TypeOfLowClouds1_observationslipform"  ng-model="obv.TypeOfLowClouds1_observationslipform"   class="form-control col-xs-12"   >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfLowClouds1_observationslipform" ng-model="obv.OktasOfLowClouds1_observationslipform"  class="form-control"  >'+
                '<option value=""></option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfLowClouds1_observationslipform"  ng-model="obv.HeightLowClouds1_observationslipform"   class="form-control input-size" >'+
          '</td>'+
          '<td colspan="1">'+
            '<select  name="CLCODEOfLowClouds1_observationslipform"  ng-model="obv.CLCODEOfLowClouds1_observationslipform"   class="form-control" >'+
                '<option value=""></option>'+
                '<option value="Sc">Sc</option>'+
                '<option value="St">St</option>'+
                '<option value="Cu">Cu</option>'+
                '<option value="Cb">Cb</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="TypeOfMediumClouds1_observationslipform"  ng-model="obv.TypeOfMediumClouds1_observationslipform"   class="form-control"   >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfMediumClouds1_observationslipform" ng-model="obv.OktasOfMediumClouds1_observationslipform"   class="form-control" >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfMediumClouds1_observationslipform"  ng-model="obv.HeightOfMediumClouds1_observationslipform"   class="form-control input-size"  >'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="CLCODEOfMediumClouds1_observationslipform"  ng-model="obv.CLCODEOfMediumClouds1_observationslipform"   class="form-control"  >'+
            '<option value=""></option>'+
            '<option value="Ac">Ac</option>'+
            '<option value="As">As</option>'+
            '<option value="Ns">Ns</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="TypeOfHighClouds1_observationslipform"  ng-model="obv.TypeOfHighClouds1_observationslipform"  class="form-control"   >'+
                '<option value=""></option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
                '<option value="9">9</option>'+
            '</select>'+
          '</td> '+
        '  <td colspan="1">'+
            '<select name="OktasOfHighClouds1_observationslipform" ng-model="obv.OktasOfHighClouds1_observationslipform"   class="form-control"  >'+
                '<option value=""></option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfHighClouds1_observationslipform"  ng-model="obv.HeightOfHighClouds1_observationslipform"   class="form-control input-size" >'+
          '</td>'+
          '<td colspan="1">'+
                          '  <select name="CLCODEOfHighClouds1_observationslipform"  ng-model="obv.CLCODEOfHighClouds1_observationslipform" class="form-control" >'+
                                '<option value=""></option>'+
                                '<option value="Cl">Cl</option>'+
                                '<option value="Cc">Cc</option>'+
                                '<option value="Cs">Cs</option>'+
                            '</select>'+
          '</td>'+
      '</tr>'+
      '<tr>'+
          '<td colspan="1">'+
            '<select  name="TypeOfLowClouds2_observationslipform"  ng-model="obv.TypeOfLowClouds2_observationslipform"  class="form-control"   >'+
              '  <option value=""></option>'+
              '  <option value="0">0</option>'+
              '  <option value="1">1</option>'+
              '  <option value="2">2</option>'+
                '<option value="3">3</option>'+
              '  <option value="4">4</option>'+
              '  <option value="5">5</option>'+
              '  <option value="6">6</option>'+
              '  <option value="7">7</option>'+
              '  <option value="8">8</option> '+
              '  <option value="9">9</option>'+
            '</select>'+
          '</td>'+
            '<td colspan="1">'+
            '<select name="OktasOfLowClouds2_observationslipform" ng-model="obv.OktasOfLowClouds2_observationslipform"  class="form-control"  >'+
                '<option value=""> </option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfLowClouds2_observationslipform"  ng-model="obv.HeightLowClouds2_observationslipform"   class="form-control input-size" >'+
          '</td>'+
          '<td colspan="1">'+
            '<select  name="CLCODEOfLowClouds2_observationslipform"  ng-model="obv.CLCODEOfLowClouds2_observationslipform"   class="form-control" >'+
                '<option value=""></option>'+
                '<option value="Sc">Sc</option>'+
                '<option value="St">St</option>'+
                '<option value="Cu">Cu</option>'+
                '<option value="Cb">Cb</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="TypeOfMediumClouds2_observationslipform"  ng-model="obv.TypeOfMediumClouds2_observationslipform"   class="form-control"   >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfMediumClouds2_observationslipform" ng-model="obv.OktasOfMediumClouds2_observationslipform"   class="form-control" >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfMediumClouds2_observationslipform"  ng-model="obv.HeightOfMediumClouds2_observationslipform"   class="form-control input-size"  >'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="CLCODEOfMediumClouds2_observationslipform"  ng-model="obv.CLCODEOfMediumClouds2_observationslipform"   class="form-control"  >'+
            '<option value=""></option>'+
            '<option value="Ac">Ac</option>'+
            '<option value="As">As</option>'+
            '<option value="Ns">Ns</option>'+
            '</select>  '+
          '</td>'+
          '<td colspan="1">'+
            '<select name="TypeOfHighClouds2_observationslipform"  ng-model="obv.TypeOfHighClouds2_observationslipform"  class="form-control"   >'+
                '<option value=""></option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
                '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfHighClouds2_observationslipform" ng-model="obv.OktasOfHighClouds2_observationslipform"   class="form-control"  >'+
                '<option value=""></option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfHighClouds2_observationslipform"  ng-model="obv.HeightOfHighClouds2_observationslipform"   class="form-control input-size" >'+
          '</td>'+
          '<td colspan="1">'+
                            '<select name="CLCODEOfHighClouds2_observationslipform"  ng-model="obv.CLCODEOfHighClouds2_observationslipform" class="form-control" > '+
                                '<option value=""></option>'+
                                '<option value="Cl">Cl</option>'+
                                '<option value="Cc">Cc</option>'+
                                '<option value="Cs">Cs</option>'+
                            '</select>'+
          '</td>'+
      '</tr>'+
      '<tr>'+
          '<td colspan="1">'+
            '<select  name="TypeOfLowClouds3_observationslipform"  ng-model="obv.TypeOfLowClouds3_observationslipform"   class="form-control col-xs-12"   >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfLowClouds3_observationslipform" ng-model="obv.OktasOfLowClouds3_observationslipform"  class="form-control"  >'+
                '<option value=""> </option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfLowClouds3_observationslipform"  ng-model="obv.HeightLowClouds3_observationslipform"   class="form-control input-size" >'+
          '</td>'+
          '<td colspan="1">'+
            '<select  name="CLCODEOfLowClouds3_observationslipform"  ng-model="obv.CLCODEOfLowClouds3_observationslipform"   class="form-control" >'+
                '<option value=""></option>'+
                '<option value="Sc">Sc</option>'+
                '<option value="St">St</option>'+
                '<option value="Cu">Cu</option>'+
                '<option value="Cb">Cb</option>'+

            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="TypeOfMediumClouds3_observationslipform"  ng-model="obv.TypeOfMediumClouds3_observationslipform"   class="form-control"   >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfMediumClouds3_observationslipform" ng-model="obv.OktasOfMediumClouds3_observationslipform"   class="form-control" >'+
            '<option value=""></option>'+
            '<option value="0">0</option>'+
            '<option value="1">1</option>'+
            '<option value="2">2</option>'+
            '<option value="3">3</option>'+
            '<option value="4">4</option>'+
            '<option value="5">5</option>'+
            '<option value="6">6</option>'+
            '<option value="7">7</option>'+
            '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfMediumClouds3_observationslipform"  ng-model="obv.HeightOfMediumClouds3_observationslipform"   class="form-control input-size"  >'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="CLCODEOfMediumClouds3_observationslipform"  ng-model="obv.CLCODEOfMediumClouds3_observationslipform"   class="form-control"  >'+
            '<option value=""></option>'+
            '<option value="Ac">Ac</option>'+
            '<option value="As">As</option>'+
            '<option value="Ns">Ns</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
          '  <select name="TypeOfHighClouds3_observationslipform"  ng-model="obv.TypeOfHighClouds3_observationslipform"  class="form-control"   >'+
              '  <option value=""></option>'+
              '  <option value="0">0</option>'+
              '  <option value="1">1</option> '+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
                '<option value="9">9</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<select name="OktasOfHighClouds3_observationslipform" ng-model="obv.OktasOfHighClouds3_observationslipform"   class="form-control"  >'+
                '<option value=""></option>'+
                '<option value="0">0</option>'+
                '<option value="1">1</option>'+
                '<option value="2">2</option>'+
                '<option value="3">3</option>'+
                '<option value="4">4</option>'+
                '<option value="5">5</option>'+
                '<option value="6">6</option>'+
                '<option value="7">7</option>'+
                '<option value="8">8</option>'+
            '</select>'+
          '</td>'+
          '<td colspan="1">'+
            '<input type="text" name="HeightOfHighClouds3_observationslipform"  ng-model="obv.HeightOfHighClouds3_observationslipform"   class="form-control input-size" >'+

          '</td>'+
          '<td colspan="1">'+
                            '<select name="CLCODEOfHighClouds3_observationslipform"  ng-model="obv.CLCODEOfHighClouds3_observationslipform" class="form-control" >'+
                                '<option value=""></option>'+
                                '<option value="Cl">Cl</option>'+
                              '  <option value="Cc">Cc</option>'+
                              '  <option value="Cs">Cs</option>'+
                          '  </select>'+
        '  </td>'+
      '</tr>'+
      '<tr><td colspan="6">'+
          '<div class="form-group col-xs-12">'+
          '    <div class="input-group">'+
          '        <span class="input-group-addon">CloudSearchLight Reading</span>'+
          '        <input type="number" name="cloudsearchlight_observationslipform"  ng-model="obv.cloudsearchlight_observationslipform"   class="form-control input-size" >'+

          '</div>'+
        '</div>'+
        '  </td>'+
        '<td colspan="6">'+
        '  <div class="form-group col-xs-12">'+
        '      <div class="input-group">'+
        '          <span class="input-group-addon">Rainfall</span>'+
                  '<input type="number" name="rainfall_observationslipform"  ng-model="obv.rainfall_observationslipform"   class="form-control input-size" >'+

          '</div>'+
        '</div>'+

      '  </td>'+
      '</tr>'+
  '</tbody>'+
'</table>'+
'<div class="modal-footer clearfix">'+
      '<button type="submit" ng-model="obv.postObservationSlipFormData_button" ng-click="openobvView(\'observationpart2\')" name="postObservationSlipFormData_button" class="btn btn-primary button-size pull-right"><i class="fa fa-plus"></i> Next</button> '+
'</div></div>';


content_in_modal +=   '<div class="row observation-form"  ng-show="observationpart2">'+
'<table class="table table-bordered">'+

  '<thead>'+

      '<tr>'+

          '<th colspan="12" class="head-center">Screen entries</th>'+


      '</tr>'+

  '</thead>'+

  '<tbody>'+
    '<tr>'+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon">Dry Bulb</span>'+
                '<input type="text" name="drybulb_observationslipform" ng-model="obv.drybulb_observationslipform"  class="form-control" placeholder="Enter Dry Bulb" >'+
            '</div>'+
        '</div>'+

      '</td>'+
      '<td colspan="6">'+
                  '  <div class="form-group col-xs-12">'+
                          '<div class="input-group">'+
                              '<span class="input-group-addon">Wet Bulb</span>'+
                              '<input type="text" name="wetbulb_observationslipform" ng-model="obv.wetbulb_observationslipform"  class="form-control" placeholder="Enter Wet Bulb" >'+
                        '  </div>'+
                    '  </div>'+
      '</td>'+
    '</tr>'+

    '<tr>'+

        '<th colspan="4" class="head-center">MAX</th>'+

        '<th colspan="4" class="head-center">MIN</th>'+

        '<th colspan="4" class="head-center">PICHE</th>'+

'        </tr>'+
      '<tr>'+
          '<td colspan="4">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon"> Read</span>'+
                  '<input type="text" name="maxRead_observationslipform"  ng-model="obv.maxRead_observationslipform"  class="form-control" placeholder="Enter MAX READ" >'+
              '</div>'+
          '</div>'+

          '<div class="form-group col-xs-12">'+
                  '<div class="input-group">'+
                      '<span class="input-group-addon"> Reset</span>'+
                      '<input type="text" name="maxReset_observationslipform" ng-model="obv.maxReset_observationslipform"  class="form-control" placeholder="Enter MAX RESET" >'+
                  '</div>'+
            '  </div>'+
            '</td> '+
          '<td colspan="4">'+
            '<div class="form-group col-xs-12"> '+
                '<div class="input-group"> '+
                    '<span class="input-group-addon"> Read</span>'+
                  '  <input type="text" name="minRead_observationslipform"  ng-model="obv.minRead_observationslipform"   class="form-control" placeholder="Enter MIN READ" >'+
              '  </div>'+
            '</div>'+

            '<div class="form-group col-xs-12">'+
                '<div class="input-group">'+
                    '<span class="input-group-addon"> Reset</span>'+
                    '<input type="text" name="minReset_observationslipform" ng-model="obv.minReset_observationslipform"   class="form-control" placeholder="Enter MIN RESET" >'+
                '</div>'+
            '</div>'+
          '</td>'+
          '<td colspan="4">'+
            '<div class="form-group col-xs-12">'+
                '<div class="input-group">'+
                    '<span class="input-group-addon"> Read</span> '+
                    '<input type="text" name="picheRead_observationslipform"  ng-model="obv.picheRead_observationslipform"   class="form-control" placeholder="Enter PICHE READ" >'+
                '</div>'+
            '</div>'+
'<div class="form-group col-xs-12">'+
                '<div class="input-group">'+
                    '<span class="input-group-addon"> Reset</span>'+
                    '<input type="text" name="picheReset_observationslipform" ng-model="obv.picheReset_observationslipform"   class="form-control" placeholder="Enter PICHE RESET" >'+
                '</div>'+
            '</div>'+
          '</td>'+

      '</tr>'+
      '<tr>'+
        '<th colspan="12" class="head-center">Time marks</th>'+
      '</tr>'+
      '<tr>'+
        '<td colspan="4">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">THERMO</span>'+
                  '<input type="text" name="timemarksThermo_observationslipform"  ng-model="obv.timemarksThermo_observationslipform"   class="form-control" placeholder="Enter TIME MARKS THERMO" >'+
              '</div>'+
          '</div>'+
        '</td>'+
        '<td colspan="4">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon"> HYGRO</span>'+
                  '<input type="text" name="timemarksHygro_observationslipform" ng-model="obv.timemarksHygro_observationslipform"  class="form-control" placeholder="Enter TIME MARKS HYGRO" >'+
              '</div>'+
'              </div>'+
  '</td>'+
        '<td colspan="4">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">RAIN REC</span>'+
                  '<input type="text" name="timemarksRainRec_observationslipform" ng-model="obv.timemarksRainRec_observationslipform"   class="form-control" placeholder="Enter TIME MARKS RAIN REC" >'+
              '</div>'+
          '</div>'+
        '</td>'+
      '</tr> '+
  '</tbody> '+

'</table>'+
'<div class="modal-footer clearfix">'+

      '<button type="submit" ng-model="obv.postObservationSlipFormData_button" ng-click="openobvView(\'observationpart3\')" name="postObservationSlipFormData_button" class="btn btn-primary button-size pull-right"><i class="fa fa-plus"></i> Next</button>'+
'<a href="" class="btn btn-danger button-size pull-left" ng-click="openobvView(\'observationpart1\')"><i class="fa fa-times"></i> back</a>'+
'</div></div>';


content_in_modal += '<div class="row observation-form" ng-show="observationpart3">'+

'<table class="table table-bordered">'+

'<thead>'+

    '<tr>'+

        '<th colspan="12" class="head-center">Office entries</th>'+


    '</tr>'+

'  </thead>'+

'<tbody>'+

  '  <tr> '+
        '<td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">Attd.Thermo.(C)</span>'+
                  '<input type="text" name="attdThermo_observationslipform" ng-model="obv.attdThermo_observationslipform"  class="form-control" placeholder="Enter ATTD.THERMO" >'+
              '</div>'+
          '</div>'+


          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">Pr.As Read(C)</span>'+
                  '<input type="text" name="prAsRead_observationslipform" ng-model="obv.prAsRead_observationslipform"   class="form-control" placeholder="Enter Pr.As Read" >'+
              '</div> '+
          '</div>'+



          '</td>'+
        '<td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">Correction</span>'+
                  '<input type="text" name="correction_observationslipform" ng-model="obv.correction_observationslipform"   class="form-control" placeholder="Enter Correction" >'+
              '</div>'+
          '</div>'+

          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">C.L.P(mb)</span>'+
                  '<input type="text" name="CLP_observationslipform" ng-model="obv.CLP_observationslipform"   class="form-control" placeholder="Enter C.L.P(mb)" >'+
              '</div>'+
          '</div>'+

        '</td>'+

    '</tr>'+

    '<tr>'+
      '<td colspan="12">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
              '  <span class="input-group-addon">M.S.L.Pr(mb) or 850mb. Ht.(gpm)</span>'+
                '<input type="text" name="MSLPR_observationslipform" ng-model="obv.MSLPR_observationslipform"  class="form-control" placeholder="Enter M.S.L.Pr(mb) or 850mb. Ht.(gpm)" > '+
          '  </div>'+
        '</div>'+
      '</td>'+
    '</tr>'+
    '<tr>'+
      '<th class="head-center" colspan="12">Time marks</th>'+
    '</tr>'+
    '<tr>'+
        '<td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group"> '+
                  '<span class="input-group-addon">TIME MARKS BAROGRAPH</span> '+
                  '<input type="text" name="timeMarksBarograph_observationslipform" ng-model="obv.timeMarksBarograph_observationslipform"  class="form-control" placeholder="Enter TIME MARKS BAROGRAPH" > '+
              '</div>'+
          '</div>'+
        '</td>'+
        '<td colspan="6">'+

                            '<div class="form-group col-xs-12">'+
                                '<div class="input-group">'+
                                    '<span class="input-group-addon">TIME MARKS ANEMOGRAPH</span>'+
                                '  <input type="text" name="timeMarksAnemograph_observationslipform" ng-model="obv.timeMarksAnemograph_observationslipform"   class="form-control" placeholder="Enter TIME MARKS ANEMOGRAPH" > '+
                              '  </div> '+
                '            </div>'+


        '</td>'+
    '</tr>'+
    '<tr>'+
      '<td colspan="12">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon">Other T/MARKS </span>'+
                '<input type="text" name="otherTMarks_observationslipform" ng-model="obv.otherTMarks_observationslipform"  class="form-control" placeholder="Enter Other T/MARKS" >'+
            '</div>'+
        '</div>'+

        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon">Remarks or any other Observations </span>'+
                '<input type="text" name="remarks_observationslipform" ng-model="obv.remarks_observationslipform"  class="form-control" placeholder="Enter Remarks or any other Observations" >'+
          '  </div>'+
        '</div>'+

      '</td>'+
    '</tr>'+
'</tbody>'+

'</table>'+
'<div class="modal-footer clearfix">'+

    '<button type="submit" ng-model="obv.postObservationSlipFormData_button" ng-click="openobvView(\'observationpart4\')" name="postObservationSlipFormData_button" class="btn btn-primary button-size pull-right"><i class="fa fa-plus"></i> Next</button>'+
'<a href="" class="btn btn-danger button-size pull-left" ng-click="openobvView(\'observationpart2\')"><i class="fa fa-times"></i> back</a>'+
'</div></div>';


content_in_modal += '<div class="row observation-form"  ng-show="observationpart4">'+

'<table class="table table-bordered">'+
'<thead>'+
    '<tr>'+
        '<th colspan="12" class="head-center">Outdoor entries</th>'+
    '</tr>'+
'</thead>'+
'<tbody>'+
  '<tr>'+
    '<td colspan="12">'+
      '<div class="form-group col-xs-12">'+
          '<div class="input-group">'+
              '<span class="input-group-addon">PRESENT WEATHER</span>'+
              '<input type="text" name="presentweather_observationslipform" ng-model="obv.presentweather_observationslipform"   class="form-control" placeholder="Enter PRESENT WEATHER" >'+
          '</div>'+
    '  </div>'+
    '</td>'+

  '</tr>'+
    '<tr>'+
        '<td colspan="6">'+
          '<div class="form-group col-xs-12">'+
              '<div class="input-group">'+
                  '<span class="input-group-addon">VISIBILITY</span>'+
                  '<input type="text" name="visibility_observationslipform" ng-model="obv.visibility_observationslipform"   class="form-control" placeholder="Enter VISIBILITY" >'+
              '</div>'+
          '</div>'+
          '</td>'+
        '<td colspan="6">'+
                            '<div class="form-group col-xs-12">'+
                                '<div class="input-group">'+
                                    '<span class="input-group-addon">GUSTING(KTS)</span> '+
                                    '<input type="text" name="gusting_observationslipform" ng-model="obv.gusting_observationslipform"   class="form-control" placeholder="Enter GUSTING (KTS)" > '+
                                '</div>'+
                            '</div>'+
        '</td>'+

    '</tr>'+
    '<tr>'+
      '<th colspan="12" class="head-center">wind</th>'+
    '</tr>'+
    '<tr>'+
      '<td colspan="6">'+
        '<div class="form-group col-xs-12">'+
            '<div class="input-group">'+
                '<span class="input-group-addon">WIND DIRECTION</span>'+
                '<input type="text" name="winddirection_observationslipform" ng-model="obv.winddirection_observationslipform"   class="form-control" placeholder="Enter WIND DIRECTION" > '+
          '  </div>'+
      '  </div>'+

      '</td>'+
      '<td colspan="6">'+

                        '<div class="form-group col-xs-12">'+
                            '<div class="input-group">'+
                                '<span class="input-group-addon">WIND SPEED(KTS)</span>'+
                                '<input type="text" name="windspeed_observationslipform" ng-model="obv.windspeed_observationslipform"   class="form-control" placeholder="Enter WIND SPEED(KTS)" >'+
                            '</div>'+
                        '</div>'+


      '</td>'+

    '</tr>'+
'</tbody>'+

'</table>'+
'  <div class="modal-footer clearfix"> '+

    '<button type="submit" ng-model="obv.postObservationSlipFormData_button" ng-click="updateObservationDataOffline('+record_id+')" name="postObservationSlipFormData_button" class="btn btn-primary button-size pull-right"><i class="fa fa-plus"></i> Update entry</button>'+
'<a href="" class="btn btn-danger button-size pull-left" ng-click="openobvView(\'observationpart3\')"><i class="fa fa-times"></i> back</a>'+
'</div></div>';

$scope.loadobvpendingview();

document.getElementById("modalContent").innerHTML = content_in_modal;

$compile(document.getElementById("myModal"))($scope);


  }

$scope.showDiv2 = function(){
  $scope.observationpart2 = true;
}


$scope.openLine = function(callback){
  if (mydb) {
          var dbdetails = [{name:'', id : ''}];
      //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
      mydb.transaction(function (t) {
          t.executeSql("SELECT * FROM observation_Table", [],   function(transaction, results) {
              //initialise the listitems variable
              var i;//Iterate through the results
            //  //alert(results.rows.length+ "olibiki")
              for (i = 0; i < results.rows.length; i++) {
                  //Get the current row
                  var row = results.rows.item(i);

                  dbdetails[i] ={ name: row.CreationDate, id: row.id};
                  //dbdetails[i].id = row.CreationDate;
                  //dbdetails.push(row.CreationDate);
                //  //alert(dbdetails.length + "oh God")
              }


              callback(dbdetails);

          });
      });
 ////alert($scope.arrayObservation[1])
  } else {
      //alert("db not found, your browser does not support web sql!");
  }



  ////alert($scope.arrayObservation[1]);
}

$scope.updateMyList=function(transaction, results) {
    //initialise the listitems variable
    var listitems = "";
    //get the car list holder ul
    var listholder = document.getElementById("mylist");
    //clear cars list ul
    listholder.innerHTML = "";
    var i;//Iterate through the results
    for (i = 0; i < results.rows.length; i++) {
        //Get the current row
        var row = results.rows.item(i);

listholder.innerHTML += "<li>" + row.Date + " - " + row.StationName +"-"+   row.StationNumber + " - "+
      row.TIME + " - "+ row.TotalAmountOfAllClouds + " - "+row.TotalAmountOfLowClouds + " - "+
      row.TypeOfLowClouds + " - "+ row.OktasOfLowClouds + " - "+row.HeightOfLowClouds + " - "+
      row.CLCODEOfLowClouds + " - "+ row.TypeOfMediumClouds + " - "+row.OktasOfMediumClouds + " - "+
      row.HeightOfMediumClouds + " - "+ row.CLCODEOfMediumClouds + " - "+row.TypeOfHighClouds + " - "+
      row.OktasOfHighClouds + "  - "+row.HeightOfMediumClouds + " - "+
      row.TypeOfLowClouds + " - "+ row.HeightOfHighClouds + " - "+row.CLCODEOfHighClouds + " - "+
      row.CloudSearchLightReading + " - "+ row.Rainfall + " - "+row.Dry_Bulb + " - "+
      row.Wet_Bulb + " - "+ row.Max_Read + " - "+row.Max_Reset + " - "+
      row.Min_Read + " - "+ row.Min_Reset + " - "+row.Piche_Read + " - "+
      row.Piche_Reset + " - "+ row.TimeMarksThermo + " - "+row.TimeMarksHygro + " - "+
      row.TimeMarksRainRec + " - "+ row.Present_Weather + " - "+row.Visibility + " - "+
      row.Wind_Direction + " - "+ row.Wind_Speed + " - "+row.Gusting + " - "+
      row.AttdThermo + " - "+ row.PrAsRead + " - "+row.Correction + " - "+
      row.CLP + " - "+ row.MSLPr + " - "+row.TimeMarksBarograph + " - "+
      row.TimeMarksAnemograph + " - "+ row.OtherTMarks + " - "+row.Remarks + " - "+  row.SubmittedBy + " - "+
      row.CreationDate  + " - "+" (<button type='submit' ng-click='deleteFromOffline("+row.id+");'>Delete Car</button>)";

$compile(document.getElementById("mylist"))($scope);

    }

}

$scope.getUserDetails= function() {

        if (mydb) {
            mydb.transaction(function (t) {
                t.executeSql("SELECT * FROM userdetailstable ",
                function(transaction, results){
                  var len = results.rows.length, i;
                  if (len>0) {
                  //do the fetching of user details
                  return [results.rows.item(0).username,results.rows.item(0).stationName,results.rows.item(0).stationNumber];
                  }
                  return ['111','11','11'];

                });
            });

          return ['00',document.getElementById("station_observationslipform").value,document.getElementById("stationNo_observationslipform").value];
        } else {
                alert("no db supported")
                return ['999','99',,'99'];
          }

}


 $scope.displayData= function() {
  //check to ensure the mydb object has been created
    if (mydb) {
        //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
        mydb.transaction(function (t) {
            t.executeSql("SELECT * FROM observation_Table", [],   $scope.updateMyList);

        });
    } else {
        alert("db not found, your browser does not support web sql!");
    }
}

//function to add the car to the database
$scope.updateObservationDataOffline = function(){
  //check to ensure the mydb object has been created

  if (mydb) {

      var  date=$scope.convertDate($scope.obv.date),
      StationName=$scope.obv.station_observationslipform,
      StationNumber=$scope.obv.stationNo_observationslipform,
        time=$scope.convertTime($scope.obv.time_observationslipform),
        TotalAmountOfAllClouds=$scope.obv.totalamountofallclouds_observationslipform,
        TotalAmountOfLowClouds=$scope.obv.totalamountoflowclouds_observationslipform,
         TypeOfLowClouds=$scope.obv.TypeOfLowClouds1_observationslipform,
         TypeOfLowClouds2=$scope.obv.TypeOfLowClouds2_observationslipform,
         TypeOfLowClouds3=$scope.obv.TypeOfLowClouds3_observationslipform,
        OktasOfLowClouds=$scope.obv.OktasOfLowClouds1_observationslipform,
        OktasOfLowClouds2=$scope.obv.OktasOfLowClouds2_observationslipform,
        OktasOfLowClouds3=$scope.obv.OktasOfLowClouds3_observationslipform,
         HeightOfLowClouds=$scope.obv.HeightLowClouds1_observationslipform,
         HeightOfLowClouds2=$scope.obv.HeightLowClouds2_observationslipform,
         HeightOfLowClouds3=$scope.obv.HeightLowClouds3_observationslipform,
        CLCODEOfLowClouds=$scope.obv.CLCODEOfLowClouds1_observationslipform,
        CLCODEOfLowClouds2=$scope.obv.CLCODEOfLowClouds2_observationslipform,
        CLCODEOfLowClouds3=$scope.obv.CLCODEOfLowClouds3_observationslipform,
         TypeOfMediumClouds=$scope.obv.TypeOfMediumClouds1_observationslipform,
         TypeOfMediumClouds2=$scope.obv.TypeOfMediumClouds2_observationslipform,
         TypeOfMediumClouds3=$scope.obv.TypeOfMediumClouds3_observationslipform,
        OktasOfMediumClouds=$scope.obv.OktasOfMediumClouds1_observationslipform,
        OktasOfMediumClouds2=$scope.obv.OktasOfMediumClouds2_observationslipform,
        OktasOfMediumClouds3=$scope.obv.OktasOfMediumClouds3_observationslipform,
        HeightOfMediumClouds=$scope.obv.HeightOfMediumClouds1_observationslipform,
        HeightOfMediumClouds2=$scope.obv.HeightOfMediumClouds2_observationslipform,
        HeightOfMediumClouds3=$scope.obv.HeightOfMediumClouds3_observationslipform,
        CLCODEOfMediumClouds=$scope.obv.CLCODEOfMediumClouds1_observationslipform,
        CLCODEOfMediumClouds2=$scope.obv.CLCODEOfMediumClouds2_observationslipform,
        CLCODEOfMediumClouds3=$scope.obv.CLCODEOfMediumClouds3_observationslipform,
        TypeOfHighClouds=$scope.obv.TypeOfHighClouds1_observationslipform,
        TypeOfHighClouds2=$scope.obv.TypeOfHighClouds2_observationslipform,
        TypeOfHighClouds3=$scope.obv.TypeOfHighClouds3_observationslipform,
          OktasOfHighClouds=$scope.obv.OktasOfHighClouds1_observationslipform,
          OktasOfHighClouds2=$scope.obv.OktasOfHighClouds2_observationslipform,
          OktasOfHighClouds3=$scope.obv.OktasOfHighClouds3_observationslipform,
        HeightOfHighClouds=$scope.obv.HeightOfHighClouds1_observationslipform,
        HeightOfHighClouds2=$scope.obv.HeightOfHighClouds2_observationslipform,
        HeightOfHighClouds3=$scope.obv.HeightOfHighClouds3_observationslipform,
        CLCODEOfHighClouds=$scope.obv.CLCODEOfHighClouds1_observationslipform,
        CLCODEOfHighClouds2=$scope.obv.CLCODEOfHighClouds2_observationslipform,
        CLCODEOfHighClouds3=$scope.obv.CLCODEOfHighClouds3_observationslipform,
         CloudSearchLightReading=$scope.obv.cloudsearchlight_observationslipform,
         Rainfall=$scope.obv.rainfall_observationslipform,
         Dry_Bulb=$scope.obv.drybulb_observationslipform,
          Wet_Bulb=$scope.obv.wetbulb_observationslipform,
           Max_Read=$scope.obv.maxRead_observationslipform,
            Max_Reset=$scope.obv.maxReset_observationslipform,
            Min_Read=$scope.obv.minRead_observationslipform,
            Min_Reset=$scope.obv.minReset_observationslipform,
            Piche_Read=$scope.obv.picheRead_observationslipform,
            Piche_Reset=$scope.obv.picheReset_observationslipform,
            TimeMarksThermo=$scope.obv.timemarksThermo_observationslipform,
            TimeMarksHygro=$scope.obv.timemarksHygro_observationslipform,
            TimeMarksRainRec=$scope.obv.timemarksRainRec_observationslipform ,
             Present_Weather=$scope.obv.presentweather_observationslipform,
             Visibility=$scope.obv.visibility_observationslipform,
            Wind_Direction=$scope.obv.winddirection_observationslipform,
            Wind_Speed=$scope.obv.windspeed_observationslipform ,
            Gusting=$scope.obv.gusting_observationslipform,
            AttdThermo=$scope.obv.attdThermo_observationslipform,
            PrAsRead=$scope.obv.prAsRead_observationslipform,
            Correction=$scope.obv.correction_observationslipform,
            clp=$scope.obv.CLP_observationslipform,
            MSLPr=$scope.obv.MSLPR_observationslipform,
            TimeMarksBarograph=$scope.obv.timeMarksBarograph_observationslipform,
            TimeMarksAnemograph=$scope.obv.timeMarksAnemograph_observationslipform,
            OtherTMarks=$scope.obv.otherTMarks_observationslipform,
            Remarks=$scope.obv.remarks_observationslipform,
            SubmittedBy="", CreationDate = new Date();




      //Test to ensure that the user has entered both a make and model
      if (TotalAmountOfAllClouds !== "" && StationNumber !== "") {

                var query = "UPDATE observation_Table SET Date=?,  StationName=?,  StationNumber=?,  TIME=?,  TotalAmountOfAllClouds=?, TotalAmountOfLowClouds=?, TypeOfLowClouds=?, TypeOfLowClouds2=?, TypeOfLowClouds3=?, OktasOfLowClouds=?, OktasOfLowClouds2=?, OktasOfLowClouds3=?, HeightOfLowClouds=?, HeightOfLowClouds2=?, HeightOfLowClouds3=?, CLCODEOfLowClouds=?, CLCODEOfLowClouds2=?, CLCODEOfLowClouds3=?, TypeOfMediumClouds=?,TypeOfMediumClouds2=?,"+
                "TypeOfMediumClouds3=?, OktasOfMediumClouds=?,OktasOfMediumClouds2=?,OktasOfMediumClouds3=?, HeightOfMediumClouds=?, HeightOfMediumClouds2=?,HeightOfMediumClouds3=?,CLCODEOfMediumClouds=?,CLCODEOfMediumClouds2=?,CLCODEOfMediumClouds3=?,TypeOfHighClouds=?,TypeOfHighClouds2=?,TypeOfHighClouds3=?, OktasOfHighClouds=?, OktasOfHighClouds2=?,OktasOfHighClouds3=?,HeightOfHighClouds=?,HeightOfHighClouds2=?,HeightOfHighClouds3=?, CLCODEOfHighClouds=?, CLCODEOfHighClouds2=?, CLCODEOfHighClouds3=?, CloudSearchLightReading=?, Rainfall=?,Dry_Bulb=?,"+ "Wet_Bulb=?, Max_Read=?, Max_Reset=?,Min_Read=?,  Min_Reset=?,Piche_Read=?,Piche_Reset=?,TimeMarksThermo=?,TimeMarksHygro=?,TimeMarksRainRec =?, Present_Weather=?,Visibility=?,Wind_Direction=?,Wind_Speed =?,Gusting=?,AttdThermo=?,PrAsRead=?,Correction=?,CLP=?,MSLPr=?,TimeMarksBarograph=?,TimeMarksAnemograph=?,OtherTMarks=?,Remarks=?,SubmittedBy=?,CreationDate=?";

      mydb.transaction(function (t) {
        alert(date+time)
        t.executeSql(query, [date,  StationName,  StationNumber,  time,  TotalAmountOfAllClouds, TotalAmountOfLowClouds, TypeOfLowClouds,TypeOfLowClouds2,TypeOfLowClouds3,
                        OktasOfLowClouds,OktasOfLowClouds2,OktasOfLowClouds3, HeightOfLowClouds,HeightOfLowClouds2,HeightOfLowClouds3, CLCODEOfLowClouds,  CLCODEOfLowClouds2, CLCODEOfLowClouds3,TypeOfMediumClouds,TypeOfMediumClouds2,TypeOfMediumClouds3, OktasOfMediumClouds,  OktasOfMediumClouds2,  OktasOfMediumClouds3, HeightOfMediumClouds, HeightOfMediumClouds2,  HeightOfMediumClouds3,  CLCODEOfMediumClouds,CLCODEOfMediumClouds2,CLCODEOfMediumClouds3,
                         TypeOfHighClouds, TypeOfHighClouds2,TypeOfHighClouds3,OktasOfHighClouds, OktasOfHighClouds2,OktasOfHighClouds3,HeightOfHighClouds,HeightOfHighClouds2,HeightOfHighClouds3, CLCODEOfHighClouds,  CLCODEOfHighClouds2,  CLCODEOfHighClouds3, CloudSearchLightReading, Rainfall,Dry_Bulb, Wet_Bulb,
                         Max_Read, Max_Reset,Min_Read,  Min_Reset,Piche_Read,Piche_Reset,TimeMarksThermo,TimeMarksHygro,TimeMarksRainRec ,
                         Present_Weather,Visibility,Wind_Direction,Wind_Speed ,Gusting,AttdThermo,PrAsRead,Correction,clp,MSLPr,TimeMarksBarograph,TimeMarksAnemograph,OtherTMarks,Remarks,SubmittedBy, CreationDate]);



          });
      } else {
          alert("You must enter a StationNumber and TotalAmountOfAllClouds!");
      }
  } else {
      alert("db not found, your browser does not support web sql!");
  }

}





 $scope.addObservationOffline=function() {
    //check to ensure the mydb object has been created

    if (mydb) {

        var  date=$scope.convertDate($scope.obv.date),
        StationName=$scope.obv.station_observationslipform,
        StationNumber=$scope.obv.stationNo_observationslipform,
          time=$scope.convertTime($scope.obv.time_observationslipform),
          TotalAmountOfAllClouds=$scope.obv.totalamountofallclouds_observationslipform,
          TotalAmountOfLowClouds=$scope.obv.totalamountoflowclouds_observationslipform,
           TypeOfLowClouds=$scope.obv.TypeOfLowClouds1_observationslipform,
           TypeOfLowClouds2=$scope.obv.TypeOfLowClouds2_observationslipform,
           TypeOfLowClouds3=$scope.obv.TypeOfLowClouds3_observationslipform,
          OktasOfLowClouds=$scope.obv.OktasOfLowClouds1_observationslipform,
          OktasOfLowClouds2=$scope.obv.OktasOfLowClouds2_observationslipform,
          OktasOfLowClouds3=$scope.obv.OktasOfLowClouds3_observationslipform,
           HeightOfLowClouds=$scope.obv.HeightLowClouds1_observationslipform,
           HeightOfLowClouds2=$scope.obv.HeightLowClouds2_observationslipform,
           HeightOfLowClouds3=$scope.obv.HeightLowClouds3_observationslipform,
          CLCODEOfLowClouds=$scope.obv.CLCODEOfLowClouds1_observationslipform,
          CLCODEOfLowClouds2=$scope.obv.CLCODEOfLowClouds2_observationslipform,
          CLCODEOfLowClouds3=$scope.obv.CLCODEOfLowClouds3_observationslipform,
           TypeOfMediumClouds=$scope.obv.TypeOfMediumClouds1_observationslipform,
           TypeOfMediumClouds2=$scope.obv.TypeOfMediumClouds2_observationslipform,
           TypeOfMediumClouds3=$scope.obv.TypeOfMediumClouds3_observationslipform,
          OktasOfMediumClouds=$scope.obv.OktasOfMediumClouds1_observationslipform,
          OktasOfMediumClouds2=$scope.obv.OktasOfMediumClouds2_observationslipform,
          OktasOfMediumClouds3=$scope.obv.OktasOfMediumClouds3_observationslipform,
          HeightOfMediumClouds=$scope.obv.HeightOfMediumClouds1_observationslipform,
          HeightOfMediumClouds2=$scope.obv.HeightOfMediumClouds2_observationslipform,
          HeightOfMediumClouds3=$scope.obv.HeightOfMediumClouds3_observationslipform,
          CLCODEOfMediumClouds=$scope.obv.CLCODEOfMediumClouds1_observationslipform,
          CLCODEOfMediumClouds2=$scope.obv.CLCODEOfMediumClouds2_observationslipform,
          CLCODEOfMediumClouds3=$scope.obv.CLCODEOfMediumClouds3_observationslipform,
          TypeOfHighClouds=$scope.obv.TypeOfHighClouds1_observationslipform,
          TypeOfHighClouds2=$scope.obv.TypeOfHighClouds2_observationslipform,
          TypeOfHighClouds3=$scope.obv.TypeOfHighClouds3_observationslipform,
            OktasOfHighClouds=$scope.obv.OktasOfHighClouds1_observationslipform,
            OktasOfHighClouds2=$scope.obv.OktasOfHighClouds2_observationslipform,
            OktasOfHighClouds3=$scope.obv.OktasOfHighClouds3_observationslipform,
          HeightOfHighClouds=$scope.obv.HeightOfHighClouds1_observationslipform,
          HeightOfHighClouds2=$scope.obv.HeightOfHighClouds2_observationslipform,
          HeightOfHighClouds3=$scope.obv.HeightOfHighClouds3_observationslipform,
          CLCODEOfHighClouds=$scope.obv.CLCODEOfHighClouds1_observationslipform,
          CLCODEOfHighClouds2=$scope.obv.CLCODEOfHighClouds2_observationslipform,
          CLCODEOfHighClouds3=$scope.obv.CLCODEOfHighClouds3_observationslipform,
           CloudSearchLightReading=$scope.obv.cloudsearchlight_observationslipform,
           Rainfall=$scope.obv.rainfall_observationslipform,
           Dry_Bulb=$scope.obv.drybulb_observationslipform,
            Wet_Bulb=$scope.obv.wetbulb_observationslipform,
             Max_Read=$scope.obv.maxRead_observationslipform,
              Max_Reset=$scope.obv.maxReset_observationslipform,
              Min_Read=$scope.obv.minRead_observationslipform,
              Min_Reset=$scope.obv.minReset_observationslipform,
              Piche_Read=$scope.obv.picheRead_observationslipform,
              Piche_Reset=$scope.obv.picheReset_observationslipform,
              TimeMarksThermo=$scope.obv.timemarksThermo_observationslipform,
              TimeMarksHygro=$scope.obv.timemarksHygro_observationslipform,
              TimeMarksRainRec=$scope.obv.timemarksRainRec_observationslipform ,
               Present_Weather=$scope.obv.presentweather_observationslipform,
               Visibility=$scope.obv.visibility_observationslipform,
              Wind_Direction=$scope.obv.winddirection_observationslipform,
              Wind_Speed=$scope.obv.windspeed_observationslipform ,
              Gusting=$scope.obv.gusting_observationslipform,
              AttdThermo=$scope.obv.attdThermo_observationslipform,
              PrAsRead=$scope.obv.prAsRead_observationslipform,
              Correction=$scope.obv.correction_observationslipform,
              clp=$scope.obv.CLP_observationslipform,
              MSLPr=$scope.obv.MSLPR_observationslipform,
              TimeMarksBarograph=$scope.obv.timeMarksBarograph_observationslipform,
              TimeMarksAnemograph=$scope.obv.timeMarksAnemograph_observationslipform,
              OtherTMarks=$scope.obv.otherTMarks_observationslipform,
              Remarks=$scope.obv.remarks_observationslipform,
              SubmittedBy="", CreationDate = new Date();




        //Test to ensure that the user has entered both a make and model
        if (TotalAmountOfAllClouds !== "" && StationNumber !== "") {
          var query = "INSERT INTO observation_Table (Date,  StationName,  StationNumber,  TIME,  TotalAmountOfAllClouds, TotalAmountOfLowClouds, TypeOfLowClouds, TypeOfLowClouds2, TypeOfLowClouds3, OktasOfLowClouds, OktasOfLowClouds2, OktasOfLowClouds3, HeightOfLowClouds, HeightOfLowClouds2, HeightOfLowClouds3, CLCODEOfLowClouds, CLCODEOfLowClouds2, CLCODEOfLowClouds3, TypeOfMediumClouds,TypeOfMediumClouds2,"+
          "TypeOfMediumClouds3, OktasOfMediumClouds,OktasOfMediumClouds2,OktasOfMediumClouds3, HeightOfMediumClouds, HeightOfMediumClouds2,HeightOfMediumClouds3,CLCODEOfMediumClouds,CLCODEOfMediumClouds2,CLCODEOfMediumClouds3,TypeOfHighClouds,TypeOfHighClouds2,TypeOfHighClouds3, OktasOfHighClouds, OktasOfHighClouds2,OktasOfHighClouds3,HeightOfHighClouds,HeightOfHighClouds2,HeightOfHighClouds3, CLCODEOfHighClouds, CLCODEOfHighClouds2, CLCODEOfHighClouds3, CloudSearchLightReading, Rainfall,Dry_Bulb,"+ "Wet_Bulb, Max_Read, Max_Reset,Min_Read,  Min_Reset,Piche_Read,Piche_Reset,TimeMarksThermo,TimeMarksHygro,TimeMarksRainRec , Present_Weather,Visibility,Wind_Direction,Wind_Speed ,Gusting,AttdThermo,PrAsRead,Correction,CLP,MSLPr,TimeMarksBarograph,TimeMarksAnemograph,OtherTMarks,Remarks,SubmittedBy,CreationDate) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        mydb.transaction(function (t) {

          t.executeSql(query, [date,  StationName,  StationNumber,  time,  TotalAmountOfAllClouds, TotalAmountOfLowClouds, TypeOfLowClouds,TypeOfLowClouds2,TypeOfLowClouds3,
                          OktasOfLowClouds,OktasOfLowClouds2,OktasOfLowClouds3, HeightOfLowClouds,HeightOfLowClouds2,HeightOfLowClouds3, CLCODEOfLowClouds,  CLCODEOfLowClouds2, CLCODEOfLowClouds3,TypeOfMediumClouds,TypeOfMediumClouds2,TypeOfMediumClouds3, OktasOfMediumClouds,  OktasOfMediumClouds2,  OktasOfMediumClouds3, HeightOfMediumClouds, HeightOfMediumClouds2,  HeightOfMediumClouds3,  CLCODEOfMediumClouds,CLCODEOfMediumClouds2,CLCODEOfMediumClouds3,
                           TypeOfHighClouds, TypeOfHighClouds2,TypeOfHighClouds3,OktasOfHighClouds, OktasOfHighClouds2,OktasOfHighClouds3,HeightOfHighClouds,HeightOfHighClouds2,HeightOfHighClouds3, CLCODEOfHighClouds,  CLCODEOfHighClouds2,  CLCODEOfHighClouds3, CloudSearchLightReading, Rainfall,Dry_Bulb, Wet_Bulb,
                           Max_Read, Max_Reset,Min_Read,  Min_Reset,Piche_Read,Piche_Reset,TimeMarksThermo,TimeMarksHygro,TimeMarksRainRec ,
                           Present_Weather,Visibility,Wind_Direction,Wind_Speed ,Gusting,AttdThermo,PrAsRead,Correction,clp,MSLPr,TimeMarksBarograph,TimeMarksAnemograph,OtherTMarks,Remarks,SubmittedBy, CreationDate]);

                $scope.displayData();

            });
        } else {
            alert("You must enter a StationNumber and TotalAmountOfAllClouds!");
        }
    } else {
        alert("db not found, your browser does not support web sql!");
    }
}


//function to remove a car from the database, passed the row id as it's only parameter

$scope.deleteFromOffline=  function(id) {
alert()
    //check to ensure the mydb object has been created
    if (mydb) {
        //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
        mydb.transaction(function (t) {
            t.executeSql("DELETE FROM observation_Table WHERE id=?", [id], $scope.displayData);
alert("deleted");
        });
    } else {
        alert("db not found, your browser does not support web sql!");
    }
}

$scope.displayData();
})

app.controller('homeCtrl', function($scope, $http, LoginService){
$scope.loginUsingOnline=function(){

  $scope.loginData = {
    'userName' : $scope.username,
    'password' : $scope.password
  };

  if($scope.loginData.userName !=null && $scope.loginData.password !=null){
  LoginService.loginUser($scope.loginData).success(function(data) {
    if (mydb) {

        alert(LoginService.getUserStation() + LoginService.getUserStationNo());
      //Insert the user entered details into the cars table, note the use of the ? placeholder, these will replaced by the data passed in as an array as the second parameter
            mydb.transaction(function (t) {
              t.executeSql("SELECT * FROM userdetailstable WHERE username = ?", [$scope.loginData.userName],
              function(transaction, results){
                var len = results.rows.length, i;
                if (len>0) {
                  alert("online Logging in ..." );
                  t.executeSql("UPDATE  userdetailstable SET password=? WHERE username = ?", [$scope.loginData.userName,$scope.loginData.password],
                    alert("inserted UPDATED")
                );
                  location.href = "newObservationFormSlip.html";
                }
                else{
                  t.executeSql("INSERT INTO userdetailstable (username, password, stationName, stationNumber) VALUES (?, ?, ?, ?)", [$scope.loginData.userName,$scope.loginData.password,LoginService.getUserStation(), LoginService.getUserStationNo()],
                    alert("inserted successfully")
                );
                }

              });


            });

              location.href = "newObservationFormSlip.html";

    } else {
        alert("db not found, your browser does not support web sql!");
    }


  }).error(function(data) {

        alert("fake details entered")
  });
}else{
    alert("Password or email is missing");
}
}

  $scope.loginUsingOffline = function() {

    $scope.loginData = {
      'userName' : $scope.username,
      'password' : $scope.password
    };


        if($scope.loginData.userName !=null && $scope.loginData.password !=null) {
          if (mydb) {
              mydb.transaction(function (t) {
                  t.executeSql("SELECT * FROM userdetailstable WHERE username = ? AND password = ?", [$scope.loginData.userName, $scope.loginData.password],
                  function(transaction, results){
                    var len = results.rows.length, i;
                    if (len>0) {
                      alert("offline Logging in ..." + len);
                      location.href = "newObservationFormSlip.html";
                    }
                    else{
                      alert("Credentials used seem Incorrect Login while online to comfirm!");
                    }

                  });
              });


          } else {
                  alert("no db supported")
            }


  }
    else {
    alert("Password or email is missing");

    }


}




  $scope.doesConnectionExist =function() {
        var xhr = new XMLHttpRequest();
        var file = "https://www.google.com/";
        var randomNum = Math.round(Math.random() * 10000);

        xhr.open('HEAD', file + "?rand=" + randomNum, true);
        xhr.send();

        xhr.addEventListener("readystatechange", processRequest, false);

        function processRequest(e) {
          if (xhr.readyState == 4) {
            if (xhr.status >= 200 && xhr.status < 304) {
              alert("connection exists!");
              $scope.loginUsingOnline();
            } else {
              alert("connection doesn't exist!");
                $scope.loginUsingOffline();
            }
          }
        }
    }

var c= null;

  $scope.usernamefromdb ="";
    $scope.outputUsers = function() {
          //  $scope.createDatabase();
          //check to ensure the mydb object has been created
          if (mydb) {
          //  var username = document.getElementById("username").value;
            //var password = document.getElementById("password").value;

              //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
              mydb.transaction(function (t) {
                  t.executeSql("SELECT * FROM userdetailstable", [],
                  function(transaction, results){
                    var len = results.rows.length, i;
                    if (len>0) {

                     $scope.usernamefromdb = results.rows.item(0).username;
                      //$scope.usernamefromdb.push(results.rows.item(0).password);
                       //$scope.usernamefromdb.push(results.rows.item(0).stationName);
                    //$scope.usernamefromdb.push(results.rows.item(0).stationNumber);

                    alert($scope.usernamefromdb);
                    }
                    else{

                    }

                  });
              });
              return c;

          } else {
              return c;
            }
      }

$scope.addcontent = function(){

      //check to ensure the mydb object has been created

}

  $scope.createDatabase = function(){



        if (window.openDatabase) {
            //Create the database the parameters are 1. the database name 2.version number 3. a description 4. the size of the database (in bytes) 1024 x 1024 = 1MB
            mydb = openDatabase("observerData_db", "0.1", "A Database of Cars I Like", 1024 * 1024);

            //create the cars table using SQL for the database using a transaction
            mydb.transaction(function (t) {
                t.executeSql("CREATE TABLE IF NOT EXISTS cars (id INTEGER PRIMARY KEY ASC, make TEXT, model TEXT)");
                t.executeSql("CREATE TABLE IF NOT EXISTS userdetailstable(username, password, stationName,stationNumber)");
            });

            alert("database created");

        } else {
            alert("WebSQL is not supported by your browser!");
        }

        $scope.doesConnectionExist();



        //function to output the list of cars in the database

        function updateCarList(transaction, results) {
            //initialise the listitems variable
            var listitems = "";
            //get the car list holder ul
            var listholder = document.getElementById("carlist");

            //clear cars list ul
            listholder.innerHTML = "";

            var i;
            //Iterate through the results
            for (i = 0; i < results.rows.length; i++) {
                //Get the current row
                var row = results.rows.item(i);

                listholder.innerHTML += "<li>" + row.make + " - " + row.model + " (<a href='javascript:void(0);' onclick='deleteCar(" + row.id + ");'>Delete Car</a>)";
            }

        }

        //function to get the list of cars from the database

        //function to add the car to the database


        //function to remove a car from the database, passed the row id as it's only parameter

        function deleteCar(id) {
            //check to ensure the mydb object has been created
            if (mydb) {
                //Get all the cars from the database with a select statement, set outputCarList as the callback function for the executeSql command
                mydb.transaction(function (t) {
                    t.executeSql("DELETE FROM cars WHERE id=?", [id], outputCars);
                });
            } else {
                alert("db not found, your browser does not support web sql!");
            }
        }

      //outputUsers();


  }






  })
    /*document.getElementById("signin").onclick = function () {



//    alert("jojo");
      alert("cnsjn");
      // outputUsers($scope.username,$scope.password);

      //  location.href = "newObservationFormSlip.html";


    };*/
